﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using 在线云商;

namespace 在线云商
{
    public class UserDAL
    {
        //创建数据连接
        public SqlConnection getConnection()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\C#WorkSpace\在线云商\App_Data\shopping.mdf;Integrated Security=True;User Instance=True");
            conn.Open();
            return conn;
        }
        //用户登陆
        public User login(string username, string password)
        {
            //获取数据库连接
            SqlConnection conn = getConnection();
            //书写sql语句
            //string sql = "select * from user";
            string sql = string.Format("select * from userinfo");
            SqlCommand com = new SqlCommand(sql,conn);
            SqlDataReader reader = com.ExecuteReader();
            User user = null;
            while(reader.HasRows)
            {
                user = new User();
                
                user.TureName = reader.GetString(1);
                user.Sex = reader.GetString(4);
                user.Email = reader.GetString(5);
            }
            conn.Close();
            return user;
            
        }
    }
}