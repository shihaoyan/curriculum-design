﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using 在线云商;

namespace 在线云商.page
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //获取界面传递过来的用户名和密码
            string username = TextBox1.Text;
            string password = TextBox2.Text;
            //通过用户名和密码调用事务层返回User对象
            User user = new UserBLL().login(username, password);
            //判断User对象是否为空
            if (user != null)
            {
                //如果不为空把User对象放入session中
                Session.Add("user", user);
                Response.Redirect("../index.aspx");
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            //如果为空跳转到登陆界面并且通过一个地方显示密码输入错误

            

            //调转到登陆界面
        }
    }
}