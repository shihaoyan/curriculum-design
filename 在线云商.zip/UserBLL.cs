﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using 在线云商;

namespace 在线云商
{
    public class UserBLL
    {
        //登陆
        public User login(string username,string password)
        {

            return new UserDAL().login(username, password);
        }


        internal void save(User user)
        {
            new UserDAL().save(user);
        }
    }
}