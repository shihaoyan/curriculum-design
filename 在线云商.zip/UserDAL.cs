﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using 在线云商;

namespace 在线云商
{
    public class UserDAL
    {
        //创建数据连接
        public SqlConnection getConnection()
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\C#WorkSpace\在线云商\App_Data\shopping.mdf;Integrated Security=True");
            conn.Open();
            return conn;
        }
        //用户登陆
        public User login(string username, string password)
        {
            //获取数据库连接
            SqlConnection conn = getConnection();
            //书写sql语句
            //string sql = "select * from user";
            string sql = string.Format("select * from [user] where username = '{0}' and password = '{1}'", username, password);
            SqlCommand com = new SqlCommand(sql,conn);
            SqlDataReader reader = com.ExecuteReader();
            User user = null;
            while(reader.Read())
            {
                user = new User();
                user.Uid = reader.GetInt32(0);
                user.TureName = reader.GetString(1);
                user.Username = reader.GetString(2);
                user.Password = reader.GetString(3);
                user.Sex = reader.GetString(4);
                user.Email = reader.GetString(5);
            }
            conn.Close();
            return user;
            
        }

        internal void save(User user)
        {
            //获取数据库连接
            SqlConnection conn = getConnection();
            //书写sql语句
            string sql = string.Format("INSERT INTO [dbo].[user] ([username], [password], [tureName], [sex], [email]) VALUES (N'{0}', N'{1}', N'{2}', N'{3}', N'{4}')",user.Username,user.Password,user.TureName,user.Sex,user.Email);
            SqlCommand com = new SqlCommand(sql, conn);
            com.ExecuteNonQuery();
        }
    }
}