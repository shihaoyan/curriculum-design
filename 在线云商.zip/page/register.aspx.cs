﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 在线云商.page
{
    public partial class register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //获取界面提交过来的数据
            User user = new User();
            Random rd = new Random();
            user.Username = TextBox1.Text;
            user.Password = TextBox2.Text;
            user.TureName = TextBox4.Text;
            user.Email    = TextBox5.Text;
            if (RadioButton1.Checked == true)
            {
                user.Sex = "男";
            }
            else if(RadioButton2.Checked == true)
            {
                user.Sex = "女";
            }
            //调用BLL层保存数据
            new UserBLL().save(user);
            //跳转到登录界面
            Server.Transfer("login.aspx");
        }
    }
}