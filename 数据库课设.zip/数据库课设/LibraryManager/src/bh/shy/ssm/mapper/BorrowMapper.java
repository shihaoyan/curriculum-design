package bh.shy.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import bh.shy.ssm.domain.Borrow;

public interface BorrowMapper {

	public <T> List<T> bookBorrowSort();

	/**
	 * 通过读者id查询读者借阅信息
	 * @param id
	 * @return
	 */
	public List<Borrow> bookBorrowByReaderId(int id);

	/**
	 * 添加借阅信息
	 * @param borr
	 */
	public void addBorrow(@Param("borr")Borrow borr);
	
	
}
