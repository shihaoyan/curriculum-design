package bh.shy.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.domain.Purview;

public interface ManagerMapper {

	/**
	 * 用户登录
	 * @param manager
	 * @return
	 */
	public Manager login(Manager manager);
	/**
	 * 管理员查询
	 * @return
	 */
	public List<Manager> managerQuery();
	/**
	 * 权限查询
	 * @param id
	 * @return
	 */
	public Manager managerModifyQuery(int id);
	
	/**
	 * 进行权限更新
	 * @param manager
	 * @param purview
	 */
	public void managerModify(@Param("manager")Manager manager, @Param("purview")Purview purview);
	/**
	 * 删除管理员权限
	 * @param id
	 */
	public void managerDel(int id);
	/**
	 * 删除管理员
	 * @param id
	 */
	public void managerDelById(int id);
	/**
	 * 插入管理员信息
	 * @param manager
	 */
	public void managerAdd(Manager manager);
	/**
	 * 插入管理员权限信息
	 * @param manager
	 */
	public void purviewAdd(Manager manager);
	
	
	
}
