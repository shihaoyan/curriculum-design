package bh.shy.ssm.mapper;

import java.util.List;

import bh.shy.ssm.domain.BookType;

public interface BookTypeMapper {

	/**
	 * 查询出所有的图书分类
	 * @return
	 */
	public List<BookType> bookTypeQuery();

	/**
	 * 添加图书类型信息
	 * @param bookType
	 */
	public void bookTypeAdd(BookType bookType);

	/**
	 * 根据id查询图书类型信息
	 * @param id
	 * @return
	 */
	public BookType bookTypeModifyQuery(int id);
	/**
	 * 根据id更改图书类型信息
	 * @param bookType
	 */
	public void bookTypeModify(BookType bookType);

	/**
	 * 根据id删除图书类型信息
	 * @param id
	 */
	public void bookTypeDel(int id);
	
}
