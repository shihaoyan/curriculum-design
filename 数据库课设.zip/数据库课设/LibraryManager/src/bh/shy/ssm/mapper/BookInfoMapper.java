package bh.shy.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import bh.shy.ssm.domain.BookInfo;

public interface BookInfoMapper {

	/**
	 * 删除图书信息
	 * @param id
	 */
	public void bookDelById(int id);

	/**
	 * 查询所有图书信息
	 * @return
	 */
	public List<BookInfo> bookQuery();

	/**
	 * 删除图书信息
	 * @param id
	 */
	public void bookDel(int id);

	/**
	 * 根据id查询图书信息
	 * @param id
	 * @return
	 */
	public BookInfo bookModifyQuery(int id);

	/**
	 * 修改图书信息
	 * @param bookInfo
	 */
	public void bookModify(@Param("bookInfo")BookInfo bookInfo);

	/**
	 * 添加图书信息
	 * @param bookInfo
	 */
	public void bookAdd(@Param("bookInfo")BookInfo bookInfo);

	/**
	 * 查询读者信息通过key
	 * @param key
	 * @return
	 */
	public BookInfo bookQueryByKey(String key);
	
}
