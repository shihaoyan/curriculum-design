package bh.shy.ssm.mapper;

import bh.shy.ssm.domain.Library;

public interface LibraryMapper {

	/**
	 * 查询所有图书信息
	 * @return
	 */
	public Library librarymodifyQuery();
	
}
