package bh.shy.ssm.mapper;

import java.util.List;

import bh.shy.ssm.domain.Publishing;

public interface PublishingMapper {

	/**
	 * 查询所有出版社
	 * @return
	 */
	List<Publishing> publishingQuery();

	
	
}
