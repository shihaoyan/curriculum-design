package bh.shy.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import bh.shy.ssm.domain.BookCase;

public interface BookCaseMapper {

	/**
	 * 查询所有书架
	 * @return
	 */
	List<BookCase> bookCaseQuery();

	/**
	 * 根据id查询书架
	 * @param id
	 * @return
	 */
	BookCase bookCaseModifyQuery(int id);

	/**
	 * 更新书架信息
	 * @param bookCase
	 */
	void bookCaseModify(@Param("bookCase")BookCase bookCase);

	/**
	 * 删除图书信息
	 * @param id
	 */
	void bookInfoDel(int id);

	/**
	 * 删除书架信息
	 * @param id
	 */
	void bookCaseDel(int id);

	/**
	 * 添加书架
	 * @param bookCase
	 */
	void bookCaseAdd(BookCase bookCase);

	
	
}
