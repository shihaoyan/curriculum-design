package bh.shy.ssm.mapper;

public interface BackMapper {

	
	
	
}
