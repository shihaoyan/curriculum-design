package bh.shy.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import bh.shy.ssm.domain.Reader;
import bh.shy.ssm.domain.ReaderType;

public interface ReaderMapper {

	/**
	 * 查询所有读者类型信息
	 * @return
	 */
	List<ReaderType> readerTypeQuery();

	/**
	 * 根据id查询读者类型信息
	 * @param id
	 * @return
	 */
	ReaderType readerTypeModifyQuery(int id);

	/**
	 * 修改读者类型
	 * @param readerType
	 */
	void readerTypeModify(ReaderType readerType);

	/**
	 * 删除读者类型信息
	 * @param id
	 */
	void readerTypeDel(int id);

	/**
	 * 添加读者类型信息
	 * @param readerType
	 */
	void readerTypeAdd(ReaderType readerType);

	/**
	 * 查询所有读者信息
	 * @return
	 */
	List<Reader> readerQuery();

	/**
	 * 查看读者详情信息
	 * @param id
	 * @return
	 */
	Reader readerDetail(int id);

	/**
	 * 修改读者信息
	 * @param reader
	 * @param typeid
	 */
	void readerModify(@Param("reader")Reader reader, @Param("typeid")int typeid);

	/**
	 * 删除读者信息
	 * @param id
	 */
	void readerDel(int id);

	/**
	 * 添加读者信息
	 * @param reader
	 * @param typeid 
	 */
	void readerAdd(@Param("reader")Reader reader, @Param("typeid")int typeid);

	/**
	 * 根据条形码查询读者信息
	 * @param barcode
	 * @return
	 */
	List<Reader> readerQueryByCode(String barcode);
	
	

	
	
}
