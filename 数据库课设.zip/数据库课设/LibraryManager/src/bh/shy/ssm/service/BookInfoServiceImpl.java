package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.BookInfo;
import bh.shy.ssm.mapper.BookInfoMapper;

@Service
public class BookInfoServiceImpl implements BookInfoService {

	@Autowired
	private BookInfoMapper bookInfoMapper;
	@Override
	public void bookDelById(int id) {
		
		bookInfoMapper.bookDelById(id);
		
	}
	@Override
	public List<BookInfo> bookQuery() {
		return bookInfoMapper.bookQuery();
	}
	@Override
	public void bookDel(int id) {
		bookInfoMapper.bookDel(id);
	}
	@Override
	public BookInfo bookModifyQuery(int id) {
		
		return bookInfoMapper.bookModifyQuery(id);
	}
	@Override
	public void bookModify(BookInfo bookInfo) {
		bookInfoMapper.bookModify(bookInfo);
	}
	@Override
	public void bookAdd(BookInfo bookInfo) {
		bookInfoMapper.bookAdd(bookInfo);
	}
	@Override
	public BookInfo bookQueryByKey(String key) {
		return bookInfoMapper.bookQueryByKey(key);
	}

}
