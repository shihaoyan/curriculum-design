package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.BookType;
import bh.shy.ssm.mapper.BookInfoMapper;
import bh.shy.ssm.mapper.BookTypeMapper;
@Service
public class BookTypeServiceImpl implements BookTypeService {

	@Autowired
	private BookTypeMapper bookTypeMapper;
	@Autowired
	private BookInfoMapper bookInfoMapper;
	
	@Override
	public List<BookType> bookTypeQuery() {
		
		
		return bookTypeMapper.bookTypeQuery();
	}
	@Override
	public void bookTypeAdd(BookType bookType) {
		bookTypeMapper.bookTypeAdd(bookType);
	}
	@Override
	public BookType bookTypeModifyQuery(int id) {
		return bookTypeMapper.bookTypeModifyQuery(id);
	}
	@Override
	public void bookTypeModify(BookType bookType) {
		bookTypeMapper.bookTypeModify(bookType);
	}
	@Override
	public void bookTypeDel(int id) {
		bookInfoMapper.bookDelById(id);
		bookTypeMapper.bookTypeDel(id);
	}
}
