package bh.shy.ssm.service;

import java.util.List;

import bh.shy.ssm.domain.Borrow;

public interface BorrowService {

	public <T>  List<T>  bookBorrowSort();

	/**
	 * 通过读者id查询借阅信息
	 * @param id
	 * @return
	 */
	public List<Borrow> bookBorrowByReaderId(int id);

	/**
	 * 添加借阅信息
	 * @param borr
	 */
	public void addBorrow(Borrow borr);
	
}
