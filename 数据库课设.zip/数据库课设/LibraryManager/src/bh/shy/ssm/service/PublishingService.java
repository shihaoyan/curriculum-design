package bh.shy.ssm.service;

import java.util.List;

import bh.shy.ssm.domain.Publishing;

public interface PublishingService {

	public List<Publishing> publishingQuery();
}
