package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.Publishing;
import bh.shy.ssm.mapper.PublishingMapper;
@Service
public class PublishingServiceImpl implements PublishingService {

	@Autowired
	private PublishingMapper publishingMapper;
	@Override
	public List<Publishing> publishingQuery() {
		
		
		return publishingMapper.publishingQuery();
	}

}
