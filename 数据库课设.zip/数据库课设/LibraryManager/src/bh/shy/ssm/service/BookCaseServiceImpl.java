package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.BookCase;
import bh.shy.ssm.mapper.BookCaseMapper;
@Service
public class BookCaseServiceImpl implements BookCaseService {

	@Autowired
	private BookCaseMapper bookCaseMapper;
	
	
	
	@Override
	public List<BookCase> bookCaseQuery() {
		
		return bookCaseMapper.bookCaseQuery();
	}
	@Override
	public BookCase bookCaseModifyQuery(int id) {
		
		return bookCaseMapper.bookCaseModifyQuery(id);
	}
	@Override
	public void bookCaseModify(BookCase bookCase) {
		bookCaseMapper.bookCaseModify(bookCase);
	}
	@Override
	public void bookCaseDel(int id) {
		//应该先删除书架上的图书信息
		bookCaseMapper.bookInfoDel(id);
		//再删除书架信息
		bookCaseMapper.bookCaseDel(id);
		
	}
	@Override
	public void bookCaseAdd(BookCase bookCase) {
		bookCaseMapper.bookCaseAdd(bookCase);
	}

}
