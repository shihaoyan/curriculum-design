package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.domain.Purview;
import bh.shy.ssm.mapper.ManagerMapper;

@Service
public class ManagerServieImpl implements  ManagerService {

	@Autowired
	private ManagerMapper managerMapper;
	/**
	 * 登陆验证
	 */
	@Override
	public Manager login(Manager manager) {
		
		return managerMapper.login(manager);
	}
	@Override
	public List<Manager> managerQuery() {
		
		return managerMapper.managerQuery();
	}
	@Override
	public Manager managerModifyQuery(int id) {
		return managerMapper.managerModifyQuery(id);
	}
	@Override
	public void managerModify(Manager manager, Purview purview) {
		managerMapper.managerModify(manager,purview);
	}
	@Override
	public void managerDel(int id) {
		managerMapper.managerDel(id);
	}
	@Override
	public void managerDelById(int id) {
		managerMapper.managerDelById(id);
	}
	@Override
	public void managerAdd(Manager manager) {
		//添加管理员
		managerMapper.managerAdd(manager);
		System.out.println(manager);
		//添加管理员权限
		managerMapper.purviewAdd(manager);
	}

	
		
	
}
