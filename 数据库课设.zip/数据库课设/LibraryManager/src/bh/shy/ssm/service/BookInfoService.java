package bh.shy.ssm.service;

import java.util.List;

import bh.shy.ssm.domain.BookInfo;

public interface BookInfoService {

	/**
	 * 根据id删除图书信息
	 * @param id
	 */
	public void bookDelById(int id);

	/**
	 * 查询所有图书信息
	 * @return
	 */
	public List<BookInfo> bookQuery();

	/**
	 * 删除图书信息
	 * @param id
	 */
	public void bookDel(int id);

	/**
	 * 根据id查询图书信息
	 * @param id
	 * @return
	 */
	public BookInfo bookModifyQuery(int id);

	/**
	 * 修改图书信息
	 * @param bookInfo
	 */
	public void bookModify(BookInfo bookInfo);

	/**
	 * 添加图书信息
	 * @param bookInfo
	 */
	public void bookAdd(BookInfo bookInfo);

	/**
	 * 获取读者信息通过key
	 * @param key
	 * @return
	 */
	public BookInfo bookQueryByKey(String key);
	
}
