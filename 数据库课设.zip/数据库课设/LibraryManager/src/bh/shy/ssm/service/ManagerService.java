package bh.shy.ssm.service;

import java.util.List;

import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.domain.Purview;

public interface ManagerService {
	
	//登陆
	public Manager login(Manager manager);
	//查询所有
	public List<Manager> managerQuery();
	//权限查询
	public Manager managerModifyQuery(int id);
	//更新权限
	public void managerModify(Manager manager, Purview purview);
	//删除管理员权限
	public void managerDel(int id);
	//删除管理员
	public void managerDelById(int id);
	//添加管理员信息
	public void managerAdd(Manager manager);
	
	
	
}
