package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.GiveBack;
import bh.shy.ssm.mapper.BackMapper;

@Service
public class BackServiceImpl implements BackService {

	@Autowired
	private BackMapper backMapper;
	public List<GiveBack> bookBack(){
		
		
		
		return null;
	}
	
}
