package bh.shy.ssm.service;

import java.util.List;

import bh.shy.ssm.domain.BookCase;
import bh.shy.ssm.domain.BookInfo;

public interface BookCaseService {
	/**
	 * 查询所有书架信息
	 * @return
	 */
	public List<BookCase> bookCaseQuery();

	/**
	 * 根据id查询书架信息
	 * @param id
	 * @return 
	 */
	public BookCase bookCaseModifyQuery(int id);

	/**
	 * 更新书架信息
	 * @param bookCase
	 */
	public void bookCaseModify(BookCase bookCase);

	/**
	 * 删除书籍信息
	 * @param id
	 */
	public void bookCaseDel(int id);

	/**
	 * 添加书架信息
	 * @param bookCase
	 */
	public void bookCaseAdd(BookCase bookCase);
	 
}
