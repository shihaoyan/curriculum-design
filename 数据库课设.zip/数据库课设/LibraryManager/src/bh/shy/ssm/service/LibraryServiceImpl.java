package bh.shy.ssm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.Library;
import bh.shy.ssm.mapper.LibraryMapper;
@Service
public class LibraryServiceImpl implements LibraryService {

	@Autowired
	private LibraryMapper libraryMapper;

	@Override
	public Library librarymodifyQuery() {
		
		return libraryMapper.librarymodifyQuery();
	}

}
