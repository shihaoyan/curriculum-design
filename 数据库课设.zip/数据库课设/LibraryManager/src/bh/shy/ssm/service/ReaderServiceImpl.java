package bh.shy.ssm.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.Reader;
import bh.shy.ssm.domain.ReaderType;
import bh.shy.ssm.mapper.ReaderMapper;
@Service
public class ReaderServiceImpl implements ReaderService {

	@Autowired
	private ReaderMapper readerMapper;
	
	@Override
	public List<ReaderType> readerTypeQuery() {
		
		
		return readerMapper.readerTypeQuery();
	}

	@Override
	public ReaderType readerTypeModifyQuery(int id) {
		
		
		return readerMapper.readerTypeModifyQuery(id);
	}

	@Override
	public void readerTypeModify(ReaderType readerType) {
		readerMapper.readerTypeModify(readerType);
	}

	@Override
	public void readerTypeDel(int id) {
		readerMapper.readerTypeDel(id);
	}

	@Override
	public void readerTypeAdd(ReaderType readerType) {
		readerMapper.readerTypeAdd(readerType);
	}

	@Override
	public List<Reader> readerQuery() {
		return readerMapper.readerQuery();
	}

	@Override
	public Reader readerDetail(int id) {
		return readerMapper.readerDetail(id);
	}

	@Override
	public void readerModify(Reader reader, int typeid) {
		readerMapper.readerModify(reader,typeid);
	}

	@Override
	public void readerDel(int id) {

		readerMapper.readerDel(id);
	}

	@Override
	public void readerAdd(Reader reader,int typeid) {
		reader.setCreateDate(new Date());
		readerMapper.readerAdd(reader,typeid);
	}

	@Override
	public List<Reader> readerQueryByCode(String barcode) {
		return readerMapper.readerQueryByCode(barcode);
	}

}
