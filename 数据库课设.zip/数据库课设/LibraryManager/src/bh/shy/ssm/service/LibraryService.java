package bh.shy.ssm.service;

import bh.shy.ssm.domain.Library;

public interface LibraryService {

	/**
	 * 查看图书馆信息
	 * @return
	 */
	public Library librarymodifyQuery();
	
}
