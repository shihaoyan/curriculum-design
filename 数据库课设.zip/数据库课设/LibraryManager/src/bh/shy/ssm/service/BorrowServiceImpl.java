package bh.shy.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bh.shy.ssm.domain.Borrow;
import bh.shy.ssm.mapper.BorrowMapper;
@Service
public class BorrowServiceImpl implements BorrowService {

	@Autowired
	private BorrowMapper borrowMapper;
	@Override
	public <T> List<T> bookBorrowSort() {
		
		
		return borrowMapper.bookBorrowSort();
	}
	@Override
	public List<Borrow> bookBorrowByReaderId(int id) {
		return borrowMapper.bookBorrowByReaderId(id);
	}
	@Override
	public void addBorrow(Borrow borr) {
		borrowMapper.addBorrow(borr);
	}

}
