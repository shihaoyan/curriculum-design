package bh.shy.ssm.test;

import java.util.Date;

import org.junit.Test;

public class DateTest {

	@Test
	public void testDate() {
		Date date = new Date();
		System.out.println(new Date(date.getTime()));
		System.out.println(new Date(date.getTime()-30*24*3600*1000));
	}
	
}
