package bh.shy.ssm.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.Library;
import bh.shy.ssm.service.LibraryService;

@Controller
@RequestMapping("libraryController")
public class LibraryController {

	@Autowired
	private LibraryService libraryService;
	
	@RequestMapping("librarymodifyQuery")
	public String librarymodifyQuery(Map<String,Object> map) {
		
		//获取图书馆信息
		Library library = libraryService.librarymodifyQuery();
		System.out.println(library);
		map.put("library",library);
		
		return "library_modify";
	}
	
	
}
