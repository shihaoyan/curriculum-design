package bh.shy.ssm.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.BookCase;
import bh.shy.ssm.service.BookCaseService;

@Controller
@RequestMapping("/bookCaseController")
public class BookCaseController {

	@Autowired
	private BookCaseService bookCaseService;
	@RequestMapping("/bookCaseQuery")
	public String bookCaseQuery(Map<String,Object> map) {
		
		
		List<BookCase> list = bookCaseService.bookCaseQuery();
		for (BookCase bookCase : list) {
			System.out.println(bookCase);
		}
		map.put("list", list);
		return "book/bookcase";
	}
	//根据id修改信息
	@RequestMapping("/bookCaseModifyQuery")
	public String bookCaseModifyQuery(Map<String,Object> map,int id) {
		
		BookCase bookcase = bookCaseService.bookCaseModifyQuery(id);
		map.put("bookcase", bookcase);
		return "book/bookCase_Modify";
	}
	//修改书架信息
	@RequestMapping("/bookCaseModify")
	public String bookCaseModify(Map<String,Object> map ,BookCase bookCase){
		
		
		
		bookCaseService.bookCaseModify(bookCase);
		
		
		map.put("para", 2);
		
		return "book/bookcase_ok";
	}
	//删除书架
	@RequestMapping("/bookCaseDel")
	public String bookCaseDel(Map<String,Object> map,int id) {
		
		bookCaseService.bookCaseDel(id);
		map.put("para", 3);
		
		return "book/bookcase_ok";
	}
	//进入到书架添加界面
	@RequestMapping("/toBookCaseAdd")
	public String toBookCaseAdd() {
		
		System.out.println("======================");
		
		return "book/bookcase_add";
	}
	//添加图书架信息
	@RequestMapping("/bookCaseAdd")
	public String bookCaseAdd(Map<String,Object> map,BookCase bookCase) {
		
		//添加书架信息
		bookCaseService.bookCaseAdd(bookCase);
		map.put("para", 1);
		
		return "book/bookcase_ok";
	}
	
	
}
