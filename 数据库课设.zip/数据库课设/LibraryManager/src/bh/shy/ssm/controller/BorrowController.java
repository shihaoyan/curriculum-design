package bh.shy.ssm.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.BookInfo;
import bh.shy.ssm.domain.Borrow;
import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.domain.Reader;
import bh.shy.ssm.domain.ReaderType;
import bh.shy.ssm.service.BookInfoService;
import bh.shy.ssm.service.BorrowService;
import bh.shy.ssm.service.ReaderService;

@Controller
@RequestMapping("/borrowController")
public class BorrowController {

	@Autowired
	private BorrowService borrowService;
	@Autowired
	private ReaderService readerService;
	@Autowired
	private BookInfoService bookInfoService;
	
	@RequestMapping("/bookBorrowSort")
	public String bookBorrowSort(HttpSession session) {
		
		//获取图书借阅信息
		List<Borrow> bookBorrowSort = borrowService.bookBorrowSort();
		Manager attribute = (Manager)session.getAttribute("manager");
		System.out.println(attribute);
		session.setAttribute("borrow", bookBorrowSort);
		
		return "redirect:/";
	}
	@RequestMapping("/toBookBorrow")
	public String toBookBorrow() {
		
		
		
		
		return "book/bookBorrow";
	}
	
	@RequestMapping("/bookBorrow")
	public String bookBorrow(Map<String,Object> map,String barcode){
		System.out.println(barcode);
		//通过读者条形码查询读者信息
		List<Reader> reader = readerService.readerQueryByCode(barcode);
		if(reader.size()==0) {
			return "book/bookBorrow";
		}
		System.out.println(reader.get(0));
		List<Borrow> borrows = borrowService.bookBorrowByReaderId(reader.get(0).getId());
		ReaderType readerType = reader.get(0).getReaderType();
		readerType.setNumber(readerType.getNumber()-borrows.size());
		map.put("readerinfo",reader.get(0));
		//查询出改读者的借阅信息
		for (Borrow borrow : borrows) {
			System.out.println(borrow);
		}
		map.put("borrows",borrows);
		return "book/bookBorrow";
	}
	@RequestMapping("/bookBorrowOk")
	public String bookBorrowOk(Map<String,Object> map,String barcode,int readerid,String key,Borrow borrow) {
		System.out.println(barcode+"===============");
		//通过key查询出图书id
		BookInfo bookInfo = bookInfoService.bookQueryByKey(key);
		//如果查询失败则跳转到错误界面
		if(bookInfo==null) {
			map.put("error", "没有该图书，不能进行借阅。");
			return "error";
		}
		Borrow borr = new Borrow();
		borr.setReader(new Reader(readerid,null,null,null,null,null,null,null,null,null,null,null,null));
		borr.setBook(bookInfo);
		borr.setIfback(0);
		Date date = new Date();
		borr.setBorrowTime(new Date(date.getTime()));
		borr.setBackTime(new Date(date.getTime()-30*24*3600*1000));
		borrowService.addBorrow(borr);
		return "forward:/borrowController/bookBorrow";
	}
	
}
