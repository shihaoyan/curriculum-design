package bh.shy.ssm.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import bh.shy.ssm.domain.Reader;
import bh.shy.ssm.domain.ReaderType;
import bh.shy.ssm.service.ReaderService;

@Controller
@RequestMapping("/readerController")
public class ReaderController {

	@Autowired
	private ReaderService readerService;
	
	
	@RequestMapping("/readerTypeQuery")
	public String readerTypeQuery(Map<String,Object> map) {
		
		//查询图书类型信息
		List<ReaderType> list = readerService.readerTypeQuery();
		map.put("list", list);
		System.out.println("===================");
		return "reader/readerType";
	}
	@RequestMapping("/readerTypeModifyQuery")
	public String readerTypeModifyQuery(Map<String,Object> map,int id) {
		
		ReaderType readerType = readerService.readerTypeModifyQuery(id);
		map.put("readerType", readerType);
		
		return "reader/readerType_Modify";
	}	
	@RequestMapping("/readerTypeModify")
	public String readerTypeModify(Map<String,Object> map,ReaderType readerType) {
		
		//进行修改数据
		readerService.readerTypeModify(readerType);
		map.put("para", 2);
		return "reader/readerType_ok";
	}
	@RequestMapping("readerTypeDel")
	public String readerTypeDel(Map<String,Object> map,int id) {
		
		readerService.readerTypeDel(id);
		map.put("para", 3);
		return "reader/readerType_ok";
	}
	@RequestMapping("/toReaderTypeAdd")
	public String toReaderTypeAdd() {
		
		return "reader/readerType_add";
	}
	@RequestMapping("readerTypeAdd")
	public String readerTypeAdd(Map<String,Object> map,ReaderType readerType) {
		
		readerService.readerTypeAdd(readerType);
		map.put("para", 1);
		return "reader/readerType_ok";
		
	}
	
	/*=================================================读者信息======================*/
	@RequestMapping("/readerQuery")
	public String readerQuery(Map<String,Object> map) {
		
		//查询所有的读者信息
		List<Reader> readers = readerService.readerQuery();
		for (Reader reader : readers) {
			System.out.println(reader);
		}
		map.put("readers", readers);
		
		return "reader/reader";
	}
	@RequestMapping("/readerDetail")
	public String readerDetail(Map<String,Object> map,int id) {
		
		//根据id查询读者信息
		Reader reader = readerService.readerDetail(id);
		map.put("reader",reader);
		return "reader/reader_detail";
	}
	@RequestMapping("/readerModifyQuery")
	public String readerModifyQuery(Map<String,Object> map,int id) {
		
		Reader reader = readerService.readerDetail(id);
		List<ReaderType> readerType = readerService.readerTypeQuery();
		map.put("readerTypes", readerType);
		map.put("reader",reader);
		return "reader/reader_Modify";
	}
	@RequestMapping("/readerModify")
	public String readerModify(Reader reader,int typeid,Map<String,Object> map) {
		//修改读者信息
		reader.setBirthday(new Date());
		System.out.println(reader);
		readerService.readerModify(reader,typeid);
		
		map.put("para", 2);
		
		return "reader/reader_ok";
	}
	@ModelAttribute
	public void getReaderById(@RequestParam(value="id",required=false) Integer id,Map<String,Object> map)
	{
		if(null != id)
		{
			
			Reader reader = readerService.readerDetail(id);
			System.out.println(reader);
			//模拟根据传入的Id参数去数据库查询，获得原始值
			map.put("reader",reader); 	
		}
	}
	@RequestMapping("/readerDel")
	public String readerDel(Map<String,Object> map,int id) {
		
		
		readerService.readerDel(id);
		
		return "reader/reader_ok";
	}
	@RequestMapping("/toReaderAdd")
	public String toReaderAdd(Map<String,Object> map) {
		
		List<ReaderType> readerTypeQuery = readerService.readerTypeQuery();
		
		map.put("readerTypes", readerTypeQuery);
		
		return "reader/reader_add";
	}
	@RequestMapping("/readerAdd")
	public String readerAdd(Map<String,Object> map,Reader reader,int typeid) {
		
		readerService.readerAdd(reader,typeid);
		map.put("para", 1);
		return "reader/reader_ok";
	}
	
	
	
	
}
