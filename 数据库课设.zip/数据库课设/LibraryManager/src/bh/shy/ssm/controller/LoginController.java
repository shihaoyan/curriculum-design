package bh.shy.ssm.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.Borrow;
import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.service.BorrowService;
import bh.shy.ssm.service.ManagerService;

@Controller
@RequestMapping(value = "/loginController")
public class LoginController {

	@Autowired
	private ManagerService managerService;
	@Autowired
	private BorrowService borrowService;

	@RequestMapping("/tologin")
	public String tologin() {
		return "login";
	}

	@RequestMapping("/login")
	public String login(HttpSession session, Map<String, Object> map, Manager manager) {
		// 把manager信息传递过去，涉及到权限的问题
		manager = managerService.login(manager);
		if (manager != null) {
			session.setAttribute("manager", manager);
			return "forward:/loginController/tomain";
		} else {
			map.put("error", "您输入的管理员名称或密码错误！");
			return "error";
		}

	}

	@RequestMapping("/tomain")
	public String tomain(HttpSession session) {

		// 获取图书借阅信息
		List<Borrow> bookBorrowSort = borrowService.bookBorrowSort();
		Manager attribute = (Manager) session.getAttribute("manager");
		System.out.println(attribute);
		session.setAttribute("borrow", bookBorrowSort);

		return "forward:/main.jsp";
	}

}
