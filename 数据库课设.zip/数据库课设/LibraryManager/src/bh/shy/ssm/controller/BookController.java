package bh.shy.ssm.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.BookCase;
import bh.shy.ssm.domain.BookInfo;
import bh.shy.ssm.domain.BookType;
import bh.shy.ssm.domain.Publishing;
import bh.shy.ssm.service.BookCaseService;
import bh.shy.ssm.service.BookInfoService;
import bh.shy.ssm.service.BookTypeService;
import bh.shy.ssm.service.PublishingService;

@Controller
@RequestMapping("/bookController")
public class BookController {

	@Autowired
	private BookInfoService bookInfoService;
	@Autowired
	private BookTypeService bookTypeService;
	@Autowired
	private PublishingService publishingService;
	@Autowired
	private BookCaseService bookCaseService;
	
	@RequestMapping("/bookQuery")
	public String bookQuery(Map<String,Object> map) {
		
		List<BookInfo> list = bookInfoService.bookQuery();
		map.put("list", list);
		
		return "book/book";
	}
	@RequestMapping("/bookDel")
	public String bookDel(Map<String,Object> map,int id) {
		
		bookInfoService.bookDel(id);
		map.put("para", 3);
		return "book/book_ok";
	}
	@RequestMapping("/bookModifyQuery")
	public String bookModifyQuery(Map<String,Object> map,int id) {
		
		BookInfo bookinfo = bookInfoService.bookModifyQuery(id);
		List<BookType> booktypes = bookTypeService.bookTypeQuery();
		List<Publishing> publishings = publishingService.publishingQuery();
		List<BookCase> cases = bookCaseService.bookCaseQuery();
		System.out.println(bookinfo);
		map.put("bookinfo", bookinfo);
		map.put("booktypes", booktypes);
		map.put("publishings", publishings);
		map.put("cases", cases);
		
		return "book/book_Modify";
		
	}
	
	@RequestMapping("/bookModify")
	public String bookModify(Map<String,Object>map,BookInfo bookInfo,int cbs,int typeId,int bookcaseid) {
		
		bookInfo.setPublishing(new Publishing(cbs,null,null));
		bookInfo.setBookType(new BookType(typeId,null,0));
		bookInfo.setBookCase(new BookCase(bookcaseid, null));
		bookInfo.setInTime(new Date());
		map.put("para", 2);
		bookInfoService.bookModify(bookInfo);
		
		
		return "book/book_ok";
	}
	@RequestMapping("/toBookAdd")
	public String toBookAdd(Map<String,Object>map) {
		
		List<BookType> booktypes = bookTypeService.bookTypeQuery();
		List<Publishing> publishings = publishingService.publishingQuery();
		List<BookCase> cases = bookCaseService.bookCaseQuery();
		map.put("booktypes", booktypes);
		map.put("publishings", publishings);
		map.put("cases", cases);
		return "book/book_add";
	}
	
	@RequestMapping("/bookAdd")
	public String bookAdd(Map<String,Object>map,BookInfo bookInfo,int cbs,int typeId,int bookcaseid) {
		
		bookInfo.setPublishing(new Publishing(cbs,null,null));
		bookInfo.setBookType(new BookType(typeId,null,0));
		bookInfo.setBookCase(new BookCase(bookcaseid, null));
		bookInfo.setInTime(new Date());
		map.put("para", 1);
		bookInfoService.bookAdd(bookInfo);
		
		
		return "book/book_ok";
	}
	@RequestMapping("/bookDetail")
	public String bookDetail(Map<String,Object>map,int id) {
		
		BookInfo bookinfo = bookInfoService.bookModifyQuery(id);
		map.put("bookinfo", bookinfo);
		
		
		return "book/book_detail";
	}
	
}
