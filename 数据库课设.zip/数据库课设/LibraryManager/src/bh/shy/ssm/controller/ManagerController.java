package bh.shy.ssm.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.Manager;
import bh.shy.ssm.domain.Purview;
import bh.shy.ssm.service.ManagerService;

@Controller
@RequestMapping("/managerController")
public class ManagerController {

	@Autowired
	private ManagerService managerService;
	
	
	@RequestMapping("/managerQuery")
	public String managerQuery(Map<String,Object> map) {
		
		List<Manager> managerList = managerService.managerQuery();
		for (Manager manager : managerList) {
			System.out.println(manager);
		}
		map.put("managerList",managerList);
		return "manager/manager";
	}
	@RequestMapping("/managerModifyQuery")
	public String managerModifyQuery(Map<String,Object> map,int id) {
		
		//通过id查询
		Manager manager = managerService.managerModifyQuery(id);
		map.put("manager", manager);
		
		return "manager/manager_Modify";
	}
	@RequestMapping("/managerModify")
	public String managerModify(Map<String,Object> map,Manager manager,Purview purview) {
		manager = managerService.managerModifyQuery(manager.getId());
		System.out.println(manager);
		System.out.println(purview);
		
		//进行更新权限
		managerService.managerModify(manager,purview);
		map.put("para", 2);
		return "manager/manager_ok";
	}
	@RequestMapping("/managerDel")
	public String managerDel(Map<String,Object> map ,int id) {
		
		//根据id删除管理员权限
		managerService.managerDel(id);
		//通过id删除管理员
		managerService.managerDelById(id);
		map.put("para", 3);
		
		return "manager/manager_ok";
	}
	@RequestMapping("/toManagerAdd")
	public String toManagerAdd() {
		return "manager/manager_add";
	}
	@RequestMapping("/managerAdd")
	public String managerAdd(Map<String,Object> map,Manager manager) {
		
		//添加管理员和权限
		managerService.managerAdd(manager);
		
		map.put("para", 1);
		
		return "manager/manager_ok";
	}
	
	
	
	
	
}
