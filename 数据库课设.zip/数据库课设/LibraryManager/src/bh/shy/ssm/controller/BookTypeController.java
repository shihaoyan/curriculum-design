package bh.shy.ssm.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import bh.shy.ssm.domain.BookType;
import bh.shy.ssm.service.BookTypeService;

@Controller
@RequestMapping("/bookTypeController")
public class BookTypeController {

	@Autowired
	private BookTypeService bookTypeService;
	
	@RequestMapping("bookTypeQuery")
	public String bookTypeQuery(Map<String,Object> map){
		
		//查询出所有的图书分类
		List<BookType> list = bookTypeService.bookTypeQuery();
		map.put("list", list);
		return "book/bookType";
		
	}
	@RequestMapping("toBookTypeAdd")
	public String toBookTypeAdd() {
		
		
		return "book/bookType_add";
	}
	@RequestMapping("/bookTypeAdd")
	public String bookTypeAdd(Map<String,Object> map,BookType bookType) {
		
		bookTypeService.bookTypeAdd(bookType);
		map.put("para",1);
		return "book/bookType_ok";
	}
	@RequestMapping("/bookTypeModifyQuery")
	public String bookTypeModifyQuery(Map<String,Object> map,int id) {
		
		//根据id查询图书类型信息
		BookType bookType = bookTypeService.bookTypeModifyQuery(id);
		map.put("bookType", bookType);
		return "book/bookType_Modify";
		
	}
	
	@RequestMapping("/bookTypeModify")
	public String bookTypeModify(Map<String,Object> map,BookType bookType) {
		
		bookTypeService.bookTypeModify(bookType);
		map.put("para", 2);
		return "book/bookType_ok";
	}
	
	@RequestMapping("/bookTypeDel")
	public String bookTypeDel(Map<String,Object> map,int id) {
		
		bookTypeService.bookTypeDel(id);
		map.put("para", 3);
		return "book/bookType_ok";
	}
	
}
