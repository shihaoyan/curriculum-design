package bh.shy.ssm.utils;

public class Page {

}
