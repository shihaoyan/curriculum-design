package bh.shy.ssm.domain;

public class BookType {

	private int id;
	private String typename;
	private int days;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTypename() {
		return typename;
	}
	public void setTypename(String typename) {
		this.typename = typename;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
	@Override
	public String toString() {
		return "BookType [id=" + id + ", typename=" + typename + ", days=" + days + "]";
	}
	public BookType(int id, String typename, int days) {
		super();
		this.id = id;
		this.typename = typename;
		this.days = days;
	}
	public BookType() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}
