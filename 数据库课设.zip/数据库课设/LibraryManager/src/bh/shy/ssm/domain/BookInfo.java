package bh.shy.ssm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class BookInfo {

	private int id;					//标识id
	private String barcode;			//条形码
	private String bookName;		//书名
	private BookType bookType;		//图书类型
	private String author;			//作者
	private String translator;		//译者
	private Publishing publishing;     //出版社
	private float price;			//价格
	private int page;				//页数
	private BookCase bookCase;		//书架信息
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date inTime;			//进货时间
	private String operator;		//操作者
	private int del;				//是否删除  0  没删除  1 删除了
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public BookType getBookType() {
		return bookType;
	}
	public void setBookType(BookType bookType) {
		this.bookType = bookType;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTranslator() {
		return translator;
	}
	public void setTranslator(String translator) {
		this.translator = translator;
	}
	public Publishing getPublishing() {
		return publishing;
	}
	public void setPublishing(Publishing publishing) {
		this.publishing = publishing;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public BookCase getBookCase() {
		return bookCase;
	}
	public void setBookCase(BookCase bookCase) {
		this.bookCase = bookCase;
	}
	public Date getInTime() {
		return inTime;
	}
	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public int getDel() {
		return del;
	}
	public void setDel(int del) {
		this.del = del;
	}
	@Override
	public String toString() {
		return "BookInfo [id=" + id + ", barcode=" + barcode + ", bookName=" + bookName + ", bookType=" + bookType
				+ ", author=" + author + ", translator=" + translator + ", publishing=" + publishing + ", price="
				+ price + ", page=" + page + ", bookCase=" + bookCase + ", inTime=" + inTime + ", operator=" + operator
				+ ", del=" + del + "]";
	}
	
	
	
	
}
