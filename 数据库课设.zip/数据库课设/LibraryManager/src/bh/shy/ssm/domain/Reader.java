package bh.shy.ssm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Reader {

	private int id;					//标识id
	private String name;			//读者姓名
	private String sex;				//读者性别
	private String barcode;			//读者条形码
	private String vocation;		//职业  学生 教师 其他
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date birthday;			//生日
	private String paperType;		//证件类型
	private String paperNO;			//证件号码
	private String tel;				//电话
	private String email;			//邮件
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date createDate;		//创建时间
	private String operator;		//操作者
	//类型
	private ReaderType readerType;	//读者类型
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public String getVocation() {
		return vocation;
	}
	public void setVocation(String vocation) {
		this.vocation = vocation;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getPaperType() {
		return paperType;
	}
	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}
	public String getPaperNO() {
		return paperNO;
	}
	public void setPaperNO(String paperNO) {
		this.paperNO = paperNO;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public ReaderType getReaderType() {
		return readerType;
	}
	public void setReaderType(ReaderType readerType) {
		this.readerType = readerType;
	}
	@Override
	public String toString() {
		return "Reader [id=" + id + ", name=" + name + ", sex=" + sex + ", barcode=" + barcode + ", vocation="
				+ vocation + ", birthday=" + birthday + ", paperType=" + paperType + ", paperNO=" + paperNO + ", tel="
				+ tel + ", email=" + email + ", createDate=" + createDate + ", operator=" + operator + ", readerType="
				+ readerType + "]";
	}
	public Reader(int id, String name, String sex, String barcode, String vocation, Date birthday, String paperType,
			String paperNO, String tel, String email, Date createDate, String operator, ReaderType readerType) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.barcode = barcode;
		this.vocation = vocation;
		this.birthday = birthday;
		this.paperType = paperType;
		this.paperNO = paperNO;
		this.tel = tel;
		this.email = email;
		this.createDate = createDate;
		this.operator = operator;
		this.readerType = readerType;
	}
	public Reader() {
	}
	
	
	
	
	
	
}
