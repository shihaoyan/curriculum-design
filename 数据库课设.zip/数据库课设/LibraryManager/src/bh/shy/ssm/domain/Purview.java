package bh.shy.ssm.domain;

public class Purview {

	private Integer id;
	private Integer sysset;
	private Integer readerset;
	private Integer bookset;
	private Integer borrowback;
	private Integer sysquery;
	private int manager_id;
	
	public int getManager_id() {
		return manager_id;
	}
	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public Integer getReaderset() {
		return readerset;
	}
	public void setReaderset(Integer readerset) {
		this.readerset = readerset;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getSysset() {
		return sysset;
	}
	public void setSysset(Integer sysset) {
		this.sysset = sysset;
	}
	public Integer getBookset() {
		return bookset;
	}
	public void setBookset(Integer bookset) {
		this.bookset = bookset;
	}
	public Integer getBorrowback() {
		return borrowback;
	}
	public void setBorrowback(Integer borrowback) {
		this.borrowback = borrowback;
	}
	public Integer getSysquery() {
		return sysquery;
	}
	public void setSysquery(Integer sysquery) {
		this.sysquery = sysquery;
	}
	@Override
	public String toString() {
		return "Purview [id=" + id + ", sysset=" + sysset + ", readerset=" + readerset + ", bookset=" + bookset
				+ ", borrowback=" + borrowback + ", sysquery=" + sysquery + ", manager_id=" + manager_id + "]";
	}

	
	
	
}
