package bh.shy.ssm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class GiveBack {

	private int id;
	private Reader  reader;
	private BookInfo book;
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date backTime;
	private String operator;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Reader getReader() {
		return reader;
	}
	public void setReader(Reader reader) {
		this.reader = reader;
	}
	public BookInfo getBook() {
		return book;
	}
	public void setBook(BookInfo book) {
		this.book = book;
	}
	public Date getBackTime() {
		return backTime;
	}
	public void setBackTime(Date backTime) {
		this.backTime = backTime;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	@Override
	public String toString() {
		return "GiveBack [id=" + id + ", reader=" + reader + ", book=" + book + ", backTime=" + backTime + ", operator="
				+ operator + "]";
	}
	public GiveBack(int id, Reader reader, BookInfo book, Date backTime, String operator) {
		super();
		this.id = id;
		this.reader = reader;
		this.book = book;
		this.backTime = backTime;
		this.operator = operator;
	}
	public GiveBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
