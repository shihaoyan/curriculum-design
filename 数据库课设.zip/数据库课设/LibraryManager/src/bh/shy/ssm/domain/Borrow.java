package bh.shy.ssm.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Borrow {

	private int id;
	private Reader reader;
	private BookInfo book;
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date borrowTime;	
	private int degree;
	@DateTimeFormat(pattern="yyyy-m-d")
	private Date backTime;			//返还日期
	private String operator;		//操作者
	private int ifback;				//1  已经换  0 没换
	public int getDegree() {
		return degree;
	}
	public void setDegree(int degree) {
		this.degree = degree;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Reader getReader() {
		return reader;
	}
	public void setReader(Reader reader) {
		this.reader = reader;
	}
	public BookInfo getBook() {
		return book;
	}
	public void setBook(BookInfo book) {
		this.book = book;
	}
	public Date getBorrowTime() {
		return borrowTime;
	}
	public void setBorrowTime(Date borrowTime) {
		this.borrowTime = borrowTime;
	}
	public Date getBackTime() {
		return backTime;
	}
	public void setBackTime(Date backTime) {
		this.backTime = backTime;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public int getIfback() {
		return ifback;
	}
	public void setIfback(int ifback) {
		this.ifback = ifback;
	}
	@Override
	public String toString() {
		return "Borrow [id=" + id + ", reader=" + reader + ", book=" + book + ", borrowTime=" + borrowTime + ", degree="
				+ degree + ", backTime=" + backTime + ", operator=" + operator + ", ifback=" + ifback + "]";
	}
	
	
	
	
	
	
}
