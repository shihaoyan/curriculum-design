package bh.shy.ssm.domain;

public class Publishing {

	private int id;
	private String ISBN;
	private String pubname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getPubname() {
		return pubname;
	}
	public void setPubname(String pubname) {
		this.pubname = pubname;
	}
	@Override
	public String toString() {
		return "Publishing [id=" + id + ", ISBN=" + ISBN + ", pubname=" + pubname + "]";
	}
	public Publishing() {
	}
	public Publishing(int id, String iSBN, String pubname) {
		this.id = id;
		ISBN = iSBN;
		this.pubname = pubname;
	}
	
	
}
