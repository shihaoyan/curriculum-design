package bh.shy.test;

public class Title {
	int x;
	int y;
	public Title(int x0, int y0) {
		x = x0;
		y = y0;
	}
}
