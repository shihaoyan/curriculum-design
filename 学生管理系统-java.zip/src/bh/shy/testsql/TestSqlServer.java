package bh.shy.testsql;

import java.sql.*;

import bh.shy.utils.JDBCUtils;

public class TestSqlServer {

	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet res = null;
		try {
			con = JDBCUtils.getConnection();
			String sql = "select * from db_test_user";// 查询test表
			statement = con.prepareStatement(sql);
			res = statement.executeQuery();
			while (res.next()) {
				String name = res.getString("uname");// 获取test_name列的元素 ;
				System.out.println("姓名：" + name);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			JDBCUtils.close(con, statement, res);
		}
	}
}