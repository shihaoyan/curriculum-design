package bh.shy.testsql;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import bh.shy.utils.JDBCUtils;

public class TestSelect {

	public static void main(String[] args) throws SQLException {
		QueryRunner qy = new QueryRunner();
		Connection conn = JDBCUtils.getConnection();
		String sql = " select * from db_test_user";

		
		
		
	}
	
}
