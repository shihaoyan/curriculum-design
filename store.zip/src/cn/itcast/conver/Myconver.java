package cn.itcast.conver;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.beanutils.Converter;

public class Myconver implements Converter {

	@Override
	public Object convert(Class arg0, Object value) {
		//class	找转换成的类型 
		//object 页面上面传入的值
		//将object转成date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date parse = sdf.parse((String)value);
			return parse; 
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}
