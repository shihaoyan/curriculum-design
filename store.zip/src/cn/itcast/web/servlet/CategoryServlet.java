package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.Category;
import cn.itcast.service.CategoryService;
import cn.itcast.service.impl.CategoryServiceImpl;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.JsonUtil;

public class CategoryServlet extends BaseServlet {

	/**
	 * 查询所有的分类
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//1.调用categoryservice查询所有分类
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		List<Category> clist = null;
		try {
			clist = cs.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String json = JsonUtil.list2json(clist);
		//写回页面
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print(json);
		return null;
	}
}
