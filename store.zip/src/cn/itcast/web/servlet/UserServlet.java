package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;

import cn.itcast.constant.Constant;
import cn.itcast.conver.Myconver;
import cn.itcast.domain.User;
import cn.itcast.service.UserService;
import cn.itcast.service.impl.UserServiceImpl;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.MD5Utils;
import cn.itcast.utils.UUIDUtils;
/**
 * 和用户相关的servlet
 * @author lenovo
 *
 */
public class UserServlet extends BaseServlet {

	public String add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("userservlet的add方法执行了");
		return null;
	}
	/**
	 * 跳转到注册页面
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String registUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		return "/jsp/register.jsp";
	}
	/**
	 * 用户注册
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception 
	 */
	public String regist(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String code = request.getParameter("code");
		
		if(!code.toUpperCase().equals(this.getServletContext().getAttribute("code"))){
			request.setAttribute("msg", "验证码输入有误");
			return "/jsp/register.jsp";
		}
		User user = new User();
		ConvertUtils.register(new Myconver(), Date.class);
		//封装数据
		Map<String, String[]> map = request.getParameterMap();
		BeanUtils.populate(user, map);
		//设置用户id
		user.setUid(UUIDUtils.getId());
		//设置激活码
		user.setCode(UUIDUtils.getCode());
		user.setPassword(MD5Utils.md5(user.getPassword()));
		//调用service完成注册
		UserService s = (UserService) BeanFactory.getBean("UserService");
		s.regist(user);
		//页面请求转发
		request.setAttribute("msg", "用户注册成功，请去邮箱激活。");	
		return "/jsp/message.jsp";
	}
	public String active(HttpServletRequest request, HttpServletResponse response)
			throws Exception{
		//获取激活码
		String code = request.getParameter("code");
		//调用service完成激活
		UserService s = (UserService) BeanFactory.getBean("UserService");
		User user = s.active(code);
		if(user == null ){
			//通过激活码没有找到用户
			request.setAttribute("msg", "请重新注册");
		}else{
			//添加信息
			request.setAttribute("msg", "激活成功");
		}
		//页面请求转发message.jsp
		
		return "/jsp/message.jsp";
				
	}
	//跳转到登陆页面
	public String loginUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		return "/jsp/login.jsp";
	}
	//用户登录
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		//获取用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String code = request.getParameter("code");
		
		if(!code.toUpperCase().equals(this.getServletContext().getAttribute("code"))){
			request.setAttribute("msg", "验证码输入有误");
			return "/jsp/login.jsp";
		}
		password = MD5Utils.md5(password);
		//调用service完成登录操作返回user
		UserService service = (UserService) BeanFactory.getBean("UserService");
		User user = service.login(username,password);
		//判断user
		if(user == null){
			//用户名密码不匹配
			request.setAttribute("msg", "用户名或密码不匹配");
			return "/jsp/login.jsp";
		}else{
			if(Constant.USER_IS_ACTIVE != user.getState()){
				
				request.setAttribute("msg", "用户未激活");
				return "/jsp/login.jsp";
			}
		}
		//讲user放入session域中重定向
		request.getSession().setAttribute("user", user);
		response.sendRedirect(request.getContextPath()+"/");
		return null;
	}
	public String logout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//干掉session
		request.getSession().invalidate();
		//重定向
		response.sendRedirect(request.getContextPath());
		//处理自动登录
		return null;
	}

}
