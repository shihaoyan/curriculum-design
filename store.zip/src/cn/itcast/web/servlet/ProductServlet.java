package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.Category;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;
import cn.itcast.service.CategoryService;
import cn.itcast.service.ProductService;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.CookieUtils;

public class ProductServlet extends BaseServlet {

	public String getById(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//获取pid
		String pid = request.getParameter("pid");
		String cid = request.getParameter("cid");
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		Category c = null;
		Product p = null;
		try {
			p = ps.getProductById(pid);
			c = cs.getCategoryById(cid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("bean", p);
		request.setAttribute("c", c);
		//1.获取指定的cookie ids
		Cookie cookie = CookieUtils.getCookieByName("ids", request.getCookies());
		//2.判断cookie是否为空
		String ids="";
		if(cookie == null){
			//需要将当前商品id放入ids中
			ids = pid;
		}else{
			//若不为空
			//继续判断ids中是否包含该产品ids
			ids = cookie.getValue();
			String [] arr = ids.split("-");
			List<String> asList = Arrays.asList(arr);
			LinkedList<String> list = new LinkedList<String>(asList);
			if(list.contains(pid)){
				//若包含id需要将id移除别放到最前面
				list.remove(pid);
				list.addFirst(pid);
			}else{
				if(list.size()>7){
					//移除最后一个
					list.removeLast();
					list.addFirst(pid);
				}else{
					list.addFirst(pid);
				}
			}
			//将list转换成字符串
			ids = "";
			for (String s : list) {
				ids+=(s+"-");
			}
			ids = ids.substring(0, ids.length()-1);
			
		}
		//将ids歇会去
		cookie = new Cookie("ids",ids);
		//设置访问路径
		cookie.setPath(request.getContextPath()+"/");
		//设置存活时间
		cookie.setMaxAge(3600);
		//写回浏览器
		response.addCookie(cookie);
		return "/jsp/product_info.jsp";
	}
	public String findByPage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//获取pid
		String cid = request.getParameter("cid");
		String currPages = request.getParameter("currPage");
		int currPage = Integer.parseInt(currPages);
		int pageSize = 12;
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		PageBean<Product> p = null;
		try {
			p = ps.findByPage(currPage,pageSize,cid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("bean", p);
		return "/jsp/product_list.jsp";
	}

}
