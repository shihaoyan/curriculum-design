package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.constant.Constant;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;
import cn.itcast.domain.User;
import cn.itcast.service.ProductService;
import cn.itcast.service.UserService;
import cn.itcast.utils.BeanFactory;

public class AdminUserServlet extends BaseServlet {

	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//查询所有用户信息
		UserService us = (UserService) BeanFactory.getBean("UserService");
		List<User> list = null;
		try {
			list = us.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "/admin/user/list.jsp";
	}
	/**
	 * 分页查询
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findByPage(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String currPages = request.getParameter("currPage");
		int currPage = Integer.parseInt(currPages);
		int pageSize = 6;
		UserService ps = (UserService) BeanFactory.getBean("UserService");
		PageBean<User> p = null;
		try {
			p = ps.findByPage(currPage,pageSize);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("bean", p);
		return "/admin/user/page_list.jsp";
	}
	/**
	 * 删除用户
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("uid");
		//调用service完成删除  ---  把用户状态更新
		UserService us = (UserService) BeanFactory.getBean("UserService");
		try {
			us.delete(uid,Constant.USER_NON_ACTIVE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminUser?method=findAll");
		return null;
	}
	/**
	 * 激活用户
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String active(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("uid");
		//调用service完成删除  ---  把用户状态更新
		UserService us = (UserService) BeanFactory.getBean("UserService");
		try {
			us.delete(uid,Constant.USER_IS_ACTIVE);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminUser?method=findAll");
		return null;
	}
	

}
