package cn.itcast.web.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;

import cn.itcast.domain.Category;
import cn.itcast.domain.Product;
import cn.itcast.service.ProductService;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.UUIDUtils;
import cn.itcast.utils.UploadUtils;

public class UpdateProductServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			//0.创建map集合 用来存放前台传递的数据
			HashMap<String, Object> map = new HashMap<String, Object>();
			//使用文件上传
			//创建磁盘文件项工厂
			DiskFileItemFactory factory = new DiskFileItemFactory();
			//创建核心上传对象
			ServletFileUpload upload = new ServletFileUpload(factory);
			//解析request
			List<FileItem> list = upload.parseRequest(request);
			//遍历集合
			for (FileItem fi : list) {
				//判断是否是普通的上传组件
				if(fi.isFormField()){
					map.put(fi.getFieldName(),fi.getString("utf-8"));
				}else{
					//文件上传组件
					
					//获取文件名称
					String name = fi.getName();
					//获取文件的真是名称
					String realName = UploadUtils.getRealName(name);
					//获取文件的随机名称
					String uuidName = UploadUtils.getUUIDName(realName);
					//获取文件的存放路径
					String path = this.getServletContext().getRealPath("/products/1");
					//获取文件的流
					InputStream is = fi.getInputStream();
					//保存图片
					FileOutputStream os = new FileOutputStream(new File(path,uuidName));
					IOUtils.copy(is, os);
					os.close();
					is.close();
					
					//删除临时文件
					fi.delete();

					//在map中设置文件的路径
					map.put(fi.getFieldName(), "products/1/"+uuidName);
				}
			}
			//1.封装参数
			Product p =new Product();
			//1.1商品id
			//p.setPid(UUIDUtils.getId());
			//1.2商品时间
			p.setPdate(new Date());
			//1.3category
			Category c = new Category();
			System.out.println((String)map.get("cid"));
			c.setCid((String)map.get("cid"));
			p.setCategory(c);
			BeanUtils.populate(p, map);
			//调用service完成添加
			ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
			ps.updateProduct(p);
			response.sendRedirect(request.getContextPath()+"/adminProduct?method=findAll");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "商品更新失败");
			request.getRequestDispatcher("/jsp/message.jsp").forward(request, response);
			return ;
		} 
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
