package cn.itcast.web.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.Cart;
import cn.itcast.domain.CartItem;
import cn.itcast.domain.Product;
import cn.itcast.service.ProductService;
import cn.itcast.utils.BeanFactory;

public class CartServlet extends BaseServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Cart getCart(HttpServletRequest request){
		Cart cart = (Cart) request.getSession().getAttribute("cart");
		if(cart == null ){
			cart = new Cart();
			request.getSession().setAttribute("cart", cart);
		}
		return cart;
	}
	//添加购物车
	public String add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//1.获取pid
		String pid = request.getParameter("pid");
		String count = request.getParameter("count");
		//获取商品
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		Product product = null;
		try {
			product = ps.getProductById(pid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//拼装购物车项
		CartItem item = new CartItem(product, Integer.parseInt(count));
		Cart cart = getCart(request);
		cart.add2Cart(item);
		response.sendRedirect(request.getContextPath()+"/jsp/cart.jsp");
		return null;
	}
	//删除商品
	public String remove(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//1.获取pid
		String pid = request.getParameter("pid");
		//获取购物车
		Cart cart = getCart(request);
		cart.removeFromCart(pid);
		response.sendRedirect(request.getContextPath()+"/jsp/cart.jsp");
		return null;
	}
	//清空购物车
	public String clearCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cart cart = getCart(request);
		cart.clearCart();
		response.sendRedirect(request.getContextPath()+"/jsp/cart.jsp");
		return null;
	}

}
