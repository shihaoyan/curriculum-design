package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.Category;
import cn.itcast.service.CategoryService;
import cn.itcast.utils.BeanFactory;

public class AdminCategoryServlet extends BaseServlet {

	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		List<Category> list = null;
		try {
			list = cs.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "/admin/category/list.jsp";
	}
	public String addCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cname = request.getParameter("cname");
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		try {
			cs.addCategory(cname);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminCategory?method=findAll");
		return null;
	}
	public String addUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		return "/admin/category/add.jsp";
	}
	public String deleteCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cid= request.getParameter("cid");
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		try {
			cs.deleteCategory(cid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminCategory?method=findAll");
		return null;
	}
	public String getById(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cid= request.getParameter("cid");
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		Category c = null;
		try {
			c = cs.getCategoryById(cid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("c", c);
		return "/admin/category/edit.jsp";
	}
	public String update(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String cid= request.getParameter("cid");
		String cname = request.getParameter("cname");
		Category c = new Category();
		c.setCid(cid);
		c.setCname(cname);
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		try {
			cs.update(c);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminCategory?method=findAll");
		return null;
	}

}
