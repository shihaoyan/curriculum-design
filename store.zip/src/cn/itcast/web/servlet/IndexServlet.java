package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.Product;
import cn.itcast.service.ProductService;
import cn.itcast.service.impl.ProductServiceImpl;

public class IndexServlet extends BaseServlet {

	public String index(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//求数据库中查询最新商品和热门商品 将他们放入request中进行转发
		ProductService ps = new ProductServiceImpl();
		
		//最新商品
		List<Product> newList = null;
		List<Product> hotList = null;
		try {
			newList = ps.findNewProduct();
			hotList = ps.findHotProduct();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		//热门商品
		
		
		//将两个list放入到request域中
		request.setAttribute("newList", newList);
		request.setAttribute("hotList", hotList);
		return "/jsp/index.jsp";

	}

}
