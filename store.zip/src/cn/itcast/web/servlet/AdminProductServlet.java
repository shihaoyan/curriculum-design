package cn.itcast.web.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.constant.Constant;
import cn.itcast.domain.Category;
import cn.itcast.domain.Product;
import cn.itcast.service.CategoryService;
import cn.itcast.service.ProductService;
import cn.itcast.utils.BeanFactory;

public class AdminProductServlet extends BaseServlet {

	/**
	 * 查询所有商品
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String findAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");	
		List<Product> list = null;
		try {
			list = ps.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "/admin/product/list.jsp";
	}
	/**
	 * 跳转到添加商品的页面
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String addUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//查询所有分类
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		List<Category> list = null;
		try{
			list = cs.findAll();
		}catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("list", list);
		return "/admin/product/add.jsp";
	}
	public String add(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		return "/admin/product/list.jsp";
	}
	/**
	 * 商品下架
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String delete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pid = request.getParameter("pid");
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		try {
			ps.update(pid,Constant.PRODUCT_NON_FLAG);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminProduct?method=findAll");
		return null;
	}
	/**
	 * 商品上架
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public String ground(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String pid = request.getParameter("pid");
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		try {
			ps.update(pid,Constant.PRODUCT_IS_FLAG);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect(request.getContextPath()+"/adminProduct?method=findAll");
		return null;
	}
	public String editUI(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//查询所有分类
		CategoryService cs = (CategoryService) BeanFactory.getBean("CategoryService");
		List<Category> list = null;
		try{
			list = cs.findAll();
		}catch (Exception e) {
			e.printStackTrace();
		}
		String pid = request.getParameter("pid");
		ProductService ps = (ProductService) BeanFactory.getBean("ProductService");
		Product p = null;
		try{
			p = ps.getProductById(pid);
		}catch (Exception e) {
			e.printStackTrace();
		}
		request.setAttribute("p", p);
		request.setAttribute("list", list);
		return "/admin/product/edit.jsp";
	}

}
