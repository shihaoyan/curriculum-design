package cn.itcast.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.itcast.domain.User;

public class PrivilegeFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		//强转	
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		//业务逻辑
		User user = (User) req.getSession().getAttribute("user");
		if(user == null){
			request.setAttribute("msg", "没有权限，请先登录");
			request.getRequestDispatcher("/jsp/message.jsp").forward(req, resp);
			return;
		}
		//放行
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}

}
