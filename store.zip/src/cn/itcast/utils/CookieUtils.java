package cn.itcast.utils;

import javax.servlet.http.Cookie;

public class CookieUtils {

	public static Cookie getCookieByName(String string, Cookie[] cookies) {
		if(cookies!=null){
			for (Cookie c : cookies) {
				//通过名称获取
				if(string.equals(c.getName())){
					return c;
				}
			}
		}
		return null;
	}
	
}
