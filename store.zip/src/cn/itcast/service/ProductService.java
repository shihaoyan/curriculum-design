package cn.itcast.service;

import java.util.List;

import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;

public interface ProductService {

	List<Product> findNewProduct() throws Exception;

	List<Product> findHotProduct() throws Exception;

	Product getProductById(String pid) throws Exception;

	PageBean<Product> findByPage(int currPage, int pageSize,String cid) throws Exception;

	List<Product> findAll() throws Exception;

	void addProduct(Product p) throws Exception;

	void update(String pid, int productIsFlag) throws Exception;

	void updateProduct(Product p) throws Exception;

}
