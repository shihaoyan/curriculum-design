package cn.itcast.service;

import cn.itcast.domain.Order;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.User;

public interface OrderService {
	
	void addOrder(Order order) throws Exception;

	PageBean findAllByPage(int parseInt, Integer pageSize, User user) throws Exception;

	Order getOrderById(String oid) throws Exception;

	void updateOrder(Order order) throws Exception;


}
