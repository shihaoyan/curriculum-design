package cn.itcast.service;

import java.util.List;

import cn.itcast.domain.Category;

public interface CategoryService {

	List<Category> findAll() throws Exception;

	Category getCategoryById(String cid) throws Exception;

	void addCategory(String cname) throws Exception;

	void deleteCategory(String cid) throws Exception;

	void update(Category c) throws Exception;


}
