package cn.itcast.service;

import java.sql.SQLException;
import java.util.List;

import cn.itcast.domain.PageBean;
import cn.itcast.domain.User;

public interface UserService {

	void regist(User user) throws Exception;

	User active(String code) throws SQLException;

	User login(String username, String password) throws Exception;

	List<User> findAll() throws Exception;

	PageBean<User> findByPage(int currPage, int pageSize) throws Exception;

	void delete(String uid, int non) throws Exception;

}
