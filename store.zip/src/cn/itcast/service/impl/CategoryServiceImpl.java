package cn.itcast.service.impl;

import java.sql.SQLException;
import java.util.List;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import cn.itcast.dao.CategoryDao;
import cn.itcast.dao.ProductDao;
import cn.itcast.domain.Category;
import cn.itcast.service.CategoryService;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.DataSourceUtils;

public class CategoryServiceImpl implements CategoryService {

	/**
	 * 查询所有的分类
	 */
	@Override
	public List<Category> findAll() throws Exception {
		//创建缓存管理器
		CacheManager cm = CacheManager.create(Category.class.getClassLoader().getResourceAsStream("ehcache.xml"));
		//获取指定的缓存
		Cache cache = cm .getCache("categoryCache");
		//通过缓存获取数据
		Element element = cache.get("clist");
		List<Category> list = null;
		//判断数据
		if(element == null){
			CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
			list = cd.findAll();
			//将list放入缓存
			cache.put(new Element("clist",list));
			
		}else{
			list = (List<Category>) element.getObjectValue();
		}
		//调用dao
		return list;
		
	}

	@Override
	public Category getCategoryById(String cid) throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		
		return cd.getCategoryById(cid);
	}

	@Override
	public void addCategory(String cname) throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		cd.add(cname);
		//更新缓存
		CacheManager cm = CacheManager.create(Category.class.getClassLoader().getResourceAsStream("ehcache.xml"));
		//获取指定的缓存
		Cache cache = cm .getCache("categoryCache");
		//清空缓存
		cache.remove("clist");
	}

	@Override
	public void deleteCategory(String cid) throws Exception{
		try {
			DataSourceUtils.startTransaction();
			ProductDao pd  = (ProductDao) BeanFactory.getBean("ProductDao");
			pd.updateCid(cid);
			CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
			cd.delete(cid);
			DataSourceUtils.commitAndClose();
			//更新缓存
			CacheManager cm = CacheManager.create(Category.class.getClassLoader().getResourceAsStream("ehcache.xml"));
			//获取指定的缓存
			Cache cache = cm .getCache("categoryCache");
			//清空缓存
			cache.remove("clist");
			
		} catch (Exception e) {
			e.printStackTrace();
			DataSourceUtils.rollbackAndClose();
			throw e;
		}
		
		
	}

	@Override
	public void update(Category c) throws Exception {
		CategoryDao cd = (CategoryDao) BeanFactory.getBean("CategoryDao");
		cd.update(c);
		CacheManager cm = CacheManager.create(Category.class.getClassLoader().getResourceAsStream("ehcache.xml"));
		//获取指定的缓存
		Cache cache = cm .getCache("categoryCache");
		//清空缓存
		cache.remove("clist");
	}

}
