package cn.itcast.service.impl;

import java.util.List;

import cn.itcast.dao.ProductDao;
import cn.itcast.dao.impl.ProductDaoImpl;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;
import cn.itcast.service.ProductService;
import cn.itcast.utils.BeanFactory;

public class ProductServiceImpl implements ProductService {

	/**
	 * 查询最新商品
	 */
	@Override
	public List<Product> findNewProduct() throws Exception {
		//调用dao
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		List<Product> newList = pd.findNew();
		return newList;
	}

	/**
	 * 查询热门商品
	 */
	@Override
	public List<Product> findHotProduct() throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		List<Product> hotList = pd.findHot();
		return hotList;
	}

	/**
	 * 通过id查找产品名称
	 */
	@Override
	public Product getProductById(String pid) throws Exception {
		//调用dao层
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		Product p = pd.getProductById(pid);
		return p;
	}

	/**
	 * 分页查询
	 */
	@Override
	public PageBean<Product> findByPage(int currPage, int pageSize,String cid)
			throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		//当前也数据
		List<Product> list =  pd.findByPage(currPage,pageSize,cid);
		//总条数
		int totalCount = pd.getTotalCount(cid);
		
		return new PageBean<Product>(list, currPage, pageSize, totalCount);
	}

	@Override
	public List<Product> findAll() throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		List<Product> list = pd.findAll();
		return list;
	}

	/**
	 * 添加商品
	 */
	@Override
	public void addProduct(Product p) throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		pd.add(p);
	}

	@Override
	public void update(String pid, int productIsFlag) throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		pd.update(pid,productIsFlag);
	}

	@Override
	public void updateProduct(Product p) throws Exception {
		ProductDao pd = (ProductDao) BeanFactory.getBean("ProductDao");
		pd.updateProduct(p);
		
	}



}
