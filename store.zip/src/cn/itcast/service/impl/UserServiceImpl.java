package cn.itcast.service.impl;

import java.sql.SQLException;
import java.util.List;

import cn.itcast.dao.UserDao;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;
import cn.itcast.domain.User;
import cn.itcast.service.UserService;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.MailUtils;

public class UserServiceImpl implements UserService {

	/**
	 * 用户注册
	 * @throws Exception 
	 */
	@Override
	public void regist(User user) throws Exception {
		UserDao dao = (UserDao) BeanFactory.getBean("UserDao");
		dao.add(user);
		//发送邮件
		MailUtils.sendMail(user.getEmail(), "欢迎你注册成为我们的一员，<a href='http://localhost:8080/store/user?method=active&code="+user.getCode()+"'>点此激活</a>");

	}

	/**
	 * 用户激活
	 * @throws SQLException 
	 */
	@Override
	public User active(String code) throws SQLException {
		UserDao dao = (UserDao) BeanFactory.getBean("UserDao");
		//通过code获取一个用户
		User user = dao.getByCode(code);
		//判断用户是否为空
		if(user == null){
			return null;
		}
		
		//修改用户状态
		user.setState(1);
		dao.update(user);
		return user;
	}

	@Override
	public User login(String username, String password) throws Exception {
		//用户登录
		UserDao dao = (UserDao) BeanFactory.getBean("UserDao");
		return dao.getByUsernameAndPwd(username,password);
	}

	@Override
	public List<User> findAll() throws Exception {
		UserDao dao = (UserDao) BeanFactory.getBean("UserDao");
		return dao.findAll();
	}

	@Override
	public PageBean<User> findByPage(int currPage, int pageSize) throws Exception {
		UserDao ud = (UserDao) BeanFactory.getBean("UserDao");
		//当前也数据
		List<User> list =  ud.findByPage(currPage,pageSize);
		//总条数
		int totalCount = ud.getCount();
		
		return new PageBean<User>(list, currPage, pageSize, totalCount);
	}

	@Override
	public void delete(String uid,int non) throws Exception {
		UserDao ud = (UserDao) BeanFactory.getBean("UserDao");
		ud.delete(uid,non);
		
	}
	
	
}
