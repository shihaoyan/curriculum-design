package cn.itcast.service.impl;

import java.util.List;

import cn.itcast.dao.OrderDao;
import cn.itcast.domain.Order;
import cn.itcast.domain.OrderItem;
import cn.itcast.domain.PageBean;
import cn.itcast.domain.User;
import cn.itcast.service.OrderService;
import cn.itcast.utils.BeanFactory;
import cn.itcast.utils.DataSourceUtils;

public class OrderServiceImpl implements OrderService {

	@Override
	public void addOrder(Order order) throws Exception {
		
		try{
			//开启事务
			DataSourceUtils.startTransaction();
			//向数据库中添加数据
			OrderDao od = (OrderDao) BeanFactory.getBean("OrderDao");
			od.add(order);
			//向orderitem中添加n条数据
			for (OrderItem oi : order.getItems()) {
				od.addItem(oi);
			}
			DataSourceUtils.commitAndClose();
		}catch (Exception e) {
			e.printStackTrace();
			DataSourceUtils.rollbackAndClose();
			throw e;
			
		}
	}

	@Override
	public PageBean findAllByPage(int currPage, Integer pageSize, User user)
			throws Exception {
		OrderDao od = (OrderDao) BeanFactory.getBean("OrderDao");
		//查询当前页的数据
		List<Order> list = od.findAllByPage(currPage,pageSize,user.getUid());
		//查询总条数
		int totalCount = od.getTotalCount(user.getUid());
		
		return new PageBean(list, currPage, pageSize, totalCount);
	}

	/**
	 * 通过订单id查询订单详情，返回订单信息
	 */
	@Override
	public Order getOrderById(String oid) throws Exception {
		OrderDao od = (OrderDao) BeanFactory.getBean("OrderDao");
		Order order = od.getOrderById(oid);
		return order;
	}

	/**
	 * 修改订单信息
	 * 收货人姓名
	 * 地址
	 * 电话
	 * 
	 */
	@Override
	public void updateOrder(Order order) throws Exception {
		OrderDao od = (OrderDao) BeanFactory.getBean("OrderDao");
		od.updata(order);
	}

}
