package cn.itcast.dao;

import java.util.List;

import cn.itcast.domain.PageBean;
import cn.itcast.domain.Product;

public interface ProductDao {

	List<Product> findNew() throws Exception;

	List<Product> findHot() throws Exception;

	Product getProductById(String pid) throws Exception;

	List<Product> findByPage(int currPage, int pageSize, String cid) throws Exception;

	int getTotalCount(String cid) throws Exception;

	void updateCid(String cid) throws Exception;

	List<Product> findAll() throws Exception;

	void add(Product p) throws Exception;

	void update(String pid, int productIsFlag) throws Exception;

	void updateProduct(Product p) throws Exception;


}
