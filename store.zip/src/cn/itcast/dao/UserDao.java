package cn.itcast.dao;

import java.sql.SQLException;
import java.util.List;

import cn.itcast.domain.User;

public interface UserDao {

	void add(User user) throws Exception;

	User getByCode(String code) throws SQLException;

	void update(User user) throws SQLException;

	User getByUsernameAndPwd(String username, String password) throws Exception;

	List<User> findAll() throws Exception;

	List<User> findByPage(int currPage, int pageSize) throws Exception;

	int getCount() throws Exception;

	void delete(String uid, int non) throws Exception;
	

}
