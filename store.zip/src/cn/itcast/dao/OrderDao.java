package cn.itcast.dao;

import java.util.List;

import cn.itcast.domain.Order;
import cn.itcast.domain.OrderItem;

public interface OrderDao {

	void add(Order order) throws Exception;

	void addItem(OrderItem oi) throws Exception;

	List<Order> findAllByPage(int currPage, Integer pageSize, String uid) throws Exception;

	int getTotalCount(String uid) throws Exception;

	Order getOrderById(String oid) throws Exception;

	void updata(Order order) throws Exception;
}
