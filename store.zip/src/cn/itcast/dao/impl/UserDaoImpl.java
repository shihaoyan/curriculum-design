package cn.itcast.dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.itcast.dao.UserDao;
import cn.itcast.domain.Product;
import cn.itcast.domain.User;
import cn.itcast.utils.DataSourceUtils;

public class UserDaoImpl implements UserDao {

	@Override
	public void add(User user) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "insert into user values(?,?,?,?,?,?,?,?,?,?)";
		qr.update(sql,user.getUid(),user.getUsername(),user.getPassword(),
				user.getName(),user.getEmail(),user.getTelephone(),
				user.getBirthday(),user.getSex(),user.getState(),user.getCode());
	}

	/**
	 * 通过code查询id
	 * @throws SQLException 
	 */
	@Override
	public User getByCode(String code) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from user where code = ? limit 1";
		return qr.query(sql, new BeanHandler<User>(User.class),code);
	}

	/**
	 * 更新用户数据
	 * @throws SQLException 
	 */
	@Override
	public void update(User user) throws SQLException {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update user set username = ?,password = ?,name = ?,email=?,birthday=?,state = ?,code = ? where uid = ?";
		qr.update(sql,user.getUsername(),user.getPassword(),user.getName(),user.getEmail(),
				user.getBirthday(),user.getState(),null,user.getUid());
	}

	@Override
	public User getByUsernameAndPwd(String username, String password)
			throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from user where username = ? and password = ?";
		return qr.query(sql, new BeanHandler<User>(User.class),username,password);
	}

	@Override
	public List<User> findAll() throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from user";
		return qr.query(sql, new BeanListHandler<User>(User.class));
	}

	@Override
	public List<User> findByPage(int currPage, int pageSize) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from user limit ?,?";
		return qr.query(sql, new BeanListHandler<User>(User.class),(currPage-1)*pageSize,pageSize);
	}

	@Override
	public int getCount() throws Exception {
		
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select count(*) from user";
		
		return ((Long)qr.query(sql, new ScalarHandler())).intValue();
	}

	@Override
	public void delete(String uid,int non) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update user set state = ? where uid = ?";
		qr.update(sql,non,uid);
	}
	
}
