package cn.itcast.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import cn.itcast.dao.OrderDao;
import cn.itcast.domain.Order;
import cn.itcast.domain.OrderItem;
import cn.itcast.domain.Product;
import cn.itcast.utils.DataSourceUtils;

public class OrderDaoImpl implements OrderDao {

	@Override
	public void add(Order order) throws Exception {
		QueryRunner qr = new QueryRunner();
		String sql = "insert into orders values(?,?,?,?,?,?,?,?)";
		qr.update(DataSourceUtils.getConnection(),sql,order.getOid(),order.getOrdertime(),order.getTotal(),order.getState(),order.getAddress(),order.getName(),order.getTelephone(),order.getUser().getUid());
	}

	@Override
	public void addItem(OrderItem oi) throws Exception {
		QueryRunner qr = new QueryRunner();
		String sql = "insert into orderitem values(?,?,?,?,?)";
		qr.update(DataSourceUtils.getConnection(),sql,oi.getItemid(),oi.getCount(),oi.getSubtotal(),oi.getProduct().getPid(),oi.getOrder().getOid());
	}

	/**
	 * 分页查询当前页数据
	 */
	@Override
	public List<Order> findAllByPage(int currPage, Integer pageSize, String uid)
			throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from orders where uid=? order by ordertime desc limit ?,?";
		List<Order> list = qr.query(sql, new BeanListHandler(Order.class),uid,(currPage-1)*pageSize,pageSize);
		String sql1 = "select * from orderitem oi,product p where oi.pid = p.pid and oi.oid = ?";
		for (Order order : list) {
			
			List<Map<String, Object>> mlist = qr.query(sql1, new MapListHandler(),order.getOid());
			for (Map<String, Object> map : mlist) {
				//封装OrderItem
				OrderItem oi = new OrderItem();
				//封装商品
				Product p = new Product();
				BeanUtils.populate(p, map);
				BeanUtils.populate(oi, map);
				//把商品传到订单项中；
				oi.setProduct(p);
				//添加到集合中
				order.getItems().add(oi);
			}
			//封装成orderitemlist
		}
		return list;
		
	}
	/**
	 * 查询数据总条数
	 */

	@Override
	public int getTotalCount(String uid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());	
		String sql = "select count(*) from orders where uid=?";
		return ((Long)qr.query(sql, new ScalarHandler(),uid)).intValue();
	}

	@Override
	public Order getOrderById(String oid) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from orders where oid = ?";
		Order order = qr.query(sql, new BeanHandler<Order>(Order.class),oid);
		
		String sql1 = "select * from orderitem oi,product p where oi.pid = p.pid and oi.oid = ?";
		List<Map<String, Object>> map = qr.query(sql1, new MapListHandler(),oid);
		for (Map<String, Object> map2 : map) {
			//封装OrderItem
			OrderItem oi = new OrderItem();
			BeanUtils.populate(oi, map2);
			//封装商品
			Product p = new Product();
			BeanUtils.populate(p, map2);
			
			//把商品传到订单项中；
			oi.setProduct(p);
			order.getItems().add(oi);
		}
		//添加到集合中
		return order;
	}

	/**
	 * 修改订单信息
	 */
	@Override
	public void updata(Order order) throws Exception {
		QueryRunner qr = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update orders set state =?,address=?,name=?,telephone=? where oid =?";
		qr.update(sql, order.getState(),order.getAddress(),order.getName(),order.getTelephone(),order.getOid());
	}

}
