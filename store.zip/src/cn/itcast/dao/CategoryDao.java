package cn.itcast.dao;

import java.util.List;

import cn.itcast.domain.Category;

public interface CategoryDao {

	List<Category> findAll() throws Exception;

	Category getCategoryById(String cid) throws Exception;

	void add(String cname) throws Exception;

	void delete(String cid) throws Exception;

	void update(Category c) throws Exception;

}
