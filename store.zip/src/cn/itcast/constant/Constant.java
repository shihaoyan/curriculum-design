package cn.itcast.constant;

public interface Constant {
	/**
	 * 用户激活状态
	 */
	int USER_IS_ACTIVE = 1;
	int USER_NON_ACTIVE = 0;
	/**
	 * 商品是否上架
	 */
	int PRODUCT_IS_FLAG = 0;
	int PRODUCT_NON_FLAG = 1;
}
