﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class UserWindow : Form
    {
        public UserWindow()
        {
            InitializeComponent();
        }

        private void UserWindow_Load(object sender, EventArgs e)
        {
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox1.Items.Add(s.Name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //调用BLL层
            DataSet ds = new UserBLL().findByName(Convert.ToString(comboBox1.SelectedItem));
            //在窗体上显示信息
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //调用BLL层
            DataSet ds = new UserDAL().findGreadByName(Convert.ToString(comboBox1.SelectedItem));
            //在窗体上显示信息
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //创建更新信息界面
            UpdateWindow update = new UpdateWindow();
            //显示出来
            update.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
