﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class DeleteWindow : Form
    {
        public DeleteWindow()
        {
            InitializeComponent();
        }
        //页面刚刚载入的时候执行下面的代码
        private void DeleteWindow_Load(object sender, EventArgs e)
        {
            
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox2.Items.Add(s.Name);
            }
        }
        //当点击删除按钮的时候调用BLL层  并把要删除的姓名传递过去。
        private void button1_Click(object sender, EventArgs e)
        {
            //调用BLL层
            
            int i =  new StudentBLL().delete(Convert.ToString(comboBox2.SelectedItem));
            if(i!=0)
            {
                success suc = new success();
                suc.Show();
                System.Threading.Thread.Sleep(2000);
                suc.Close();
                this.Close();
            }else
            {
                error er = new error();
                er.Show();
                System.Threading.Thread.Sleep(2000);
                er.Close();
            }

        }
    }
}
