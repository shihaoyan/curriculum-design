﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class UpdateWindow : Form
    {
        public UpdateWindow()
        {
            InitializeComponent();
        }

        
        //当页面刚刚载入的时候执行下面代码
        private void UpdateWindow_Load(object sender, EventArgs e)
        {
            //先把按钮设置没默认选中男
            radioButton1.Checked = true;
            
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox1.Items.Add(s.Name);
            }
        }
        //更新信息按钮被点击执行下面代码
        private void button1_Click(object sender, EventArgs e)
        {
            //封装数据
            Student s = new Student();
            s.Name = Convert.ToString(comboBox1.SelectedItem);
            s.Sid = Convert.ToString(textBox1.Text);
            s.Age = Convert.ToInt32(comboBox2.SelectedItem);
            if (radioButton1.Checked)
            {
                s.Sex = "男";
            }
            else
            {
                s.Sex = "女";
            }
            s.School = Convert.ToString(comboBox3.SelectedItem);
            s.Major = Convert.ToString(comboBox4.SelectedItem);
            s.Sclass = Convert.ToString(comboBox5.SelectedItem);
            //调用BLL层
            int i = new StudentBLL().updateMes(s);
            if (i != 0)
            {
               
                success suc = new success();
                suc.Show();
                //程序执行到这里要等待2秒。
                System.Threading.Thread.Sleep(2000);
                //关闭操作成功界面
                suc.Close();
            }
          
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }
    }
}
