﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class error : Form
    {
        public error()
        {
            InitializeComponent();
        }

        private void error_Load(object sender, EventArgs e)
        {
        }
    }
}
