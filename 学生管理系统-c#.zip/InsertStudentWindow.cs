﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class InsertStudentWindow : Form
    {
        public InsertStudentWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //封装数据
            Student s = new Student();
            s.Name = textBox2.Text;
            s.Sid = textBox3.Text;
            s.Age = Convert.ToInt32(comboBox1.SelectedItem);

            if (radioButton1.Checked)
            {
                s.Sex = "男";
            }
            if (radioButton2.Checked)
            {
                s.Sex = "女";
            }
            s.School = (string)comboBox2.SelectedItem;
            s.Major = (string)comboBox3.SelectedItem;
            s.Sclass = (string)comboBox4.SelectedItem;
            //调用BLL层添加数据  把封装了信息的Student对象 s 传递过去。
            new StudentBLL().insertStudent(s);
            //显示添加成功
            success suc = new success();
            suc.Show();
            System.Threading.Thread.Sleep(2000);
            suc.Close();
            this.Close();
        }

        private void InsertStudentWindow_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }
    }
}
