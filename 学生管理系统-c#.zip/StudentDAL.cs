﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    class StudentDAL
    {
        string path = UserDAL.findPath();
        //查询所有学生信息
        public DataSet findAll()
        {
            
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select name,sid,age,sex,school,major,sclass from  Student";
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds,"Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //通过姓名查找所有学生信息
        public DataSet findStudentByName(string name)
        {
            
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                //sql语句含义通过传递过来的姓名查询 namesid。。。字段
                string sql = "select name,sid,age,sex,school,major,sclass from  Student where name like '"+name+"'";
                //表示用于填充DataSet和更新数据库的一个命令和数据库链接
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                //创建一个DataSet
                DataSet ds = new DataSet();
                //这个Fill方法是用来想Dataset中存放表的
                sda.Fill(ds,"Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //通过班级查找所有学生基本信息
        public DataSet findStudentByClass(string sclass)
        {


            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                //在这里用到了拼接字符串
                //为什么用like---因为当初创建数据库的时候不小心把nchar类型设置成了text类型  而text类型不能用=所以只能用like
                //而单引号是因为sql语句中string类型的数据应该用单引号括起来，里面在添加"+变量+"  这就是拼接字符串
                string sql = "select name,sid,age,sex,school,major,sclass from  Student where sclass like '"+sclass+"'";
                //表示用于填充DataSet和更新数据库的一个命令和数据库链接
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                //创建一个DataSet
                DataSet ds = new DataSet();
                //这个Fill方法是用来想Dataset中存放表的。
                sda.Fill(ds,"Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //通过专业查找学生信息
        //同上
        public DataSet findStudentByMajor(string major)
        {


            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select name,sid,age,sex,school,major,sclass from  Student where major like '"+major+"'";
                SqlDataAdapter sda = new SqlDataAdapter(sql,conn);
                DataSet ds = new DataSet();
                sda.Fill(ds, "Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //通过名字查找学生成绩
        
        public List<Student> findGreadByName(string name)
        {


            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select * from  Student";
                SqlCommand comm = new SqlCommand(sql, conn);
                SqlDataReader read = comm.ExecuteReader();
                List<Student> list = new List<Student>();
                while (read.Read())
                {
                    if (read.GetString(0) == name)
                    {
                        Student s = new Student();
                        s.Name = read.GetString(0);
                        s.Sid = read.GetString(1);
                        s.Age = read.GetInt32(2);
                        s.Sex = read.GetString(3);
                        s.School = read.GetString(4);
                        s.Major = read.GetString(5);
                        s.Sclass = read.GetString(6);
                        s.C = Convert.ToDouble(read.GetValue(7));
                        s.English = Convert.ToDouble(read.GetValue(8));
                        s.Math = Convert.ToDouble(read.GetValue(9));
                        s.Chinese = Convert.ToDouble(read.GetValue(10));
                        s.Phy = Convert.ToDouble(read.GetValue(11));
                        s.Sum = Convert.ToDouble(read.GetValue(12));
                        //s.Num = Convert.ToDouble(read.GetValue(13));
                        list.Add(s);
                    }
                }
                return list;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //显示所有学生的成绩
        public DataSet findAllGread()
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select * from  Student";
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds, "Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //添加学生的基本信息
        public void insertStudent(Student s)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql  = "insert into Student (name,sid,age,sex,school,major,sclass) values('"+s.Name+"','"+s.Sid+ "','"+s.Age + "','" + s.Sex+"','"+s.School+"','"+s.Major+"','"+s.Sclass+"')";
                //获取一个可以执行语句的方法
                SqlCommand comm = new SqlCommand(sql, conn);
                //执行语句---添加数据
                comm.ExecuteNonQuery();
            }
            catch(Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        //查找所有的学生 
        //查询所有学生并封装到list集合中，并且返回。
        public List<Student> findAllStudent()
        {

            //声明一个链接对象
            SqlConnection conn = null;
            try
            {
                //创建链接
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                //打开数据库连接
                conn.Open();
                //书写sql语句  用来操作数据库的。
                string sql = "select * from  Student";
                //SqlCommand是获取一个  执行sql语句指令的对象。
                SqlCommand comm = new SqlCommand(sql, conn);
                //得到一个从化数据库中读取行的方式 read读取的是每一行数据
                SqlDataReader read = comm.ExecuteReader();
                //创建一个list集合用来储存Student对象。
                List<Student> list = new List<Student>();
              
                while (read.Read()) //如果下一行存在数据进入循环
                {
                    //先创建一个Student对象
                    Student s = new Student();
                
                    s.Name = read.GetString(0);
                    //把这个封装了姓名的学生储存到list集合中。
                    list.Add(s);
                }
                //返回到BLL层
                return list;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //添加成绩
        public int addGread(Student s)
        {
            //创建链接
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "update Student set c = '"+s.C+"',english = '"+s.English+"',math='"+s.Math+"',chinese = '"+s.Chinese+"',phy = '"+s.Phy+"',sum = '"+s.Sum+"' where name like '"+s.Name+"'";
                SqlCommand comm = new SqlCommand(sql, conn);
                return comm.ExecuteNonQuery();
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
        //更新学生信息
        //从这个方法向下全是王恒萱的。
        public int updateMes(Student s)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                //更新的sql语句 
                string sql = "update Student set sid = '"+s.Sid+"',age = '"+s.Age+"',sex='"+s.Sex+"',school = '"+s.School+"',major = '"+s.Major+"',sclass = '"+s.Sclass+"' where name like '"+s.Name+"'";
                SqlCommand comm = new SqlCommand(sql, conn);
                //执行更新语句。
                return comm.ExecuteNonQuery();
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
        //删除学生信息
        public int delete(string name)
        {
            //创建链接
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = " delete from Student where name like '"+name+"'";
                SqlCommand comm = new SqlCommand(sql, conn);
                return comm.ExecuteNonQuery();
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
    }
}
