﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    public partial class StudentMsg : Form
    {
        public StudentMsg()
        {
            InitializeComponent();
        }
        //当查询界面刚一载入的时候执行下列代码。
        private void StudentMsg_Load(object sender, EventArgs e)
        {
           
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox3.Items.Add(s.Name);
            }
        }

        
        //显示所有信息
        private void button1_Click(object sender, EventArgs e)
        {
            //调用service层 返回Student
            
            
            DataSet ds = new StudentBLL().findAll();
            //在窗体上显示信息
            dataGridView1.DataSource = ds.Tables["Student"];
        }
        //调用BLL层通过姓名查询所有的学生信息
        private void button2_Click(object sender, EventArgs e)
        {
            //调用service层 返回DateSet
            DataSet ds   = new StudentBLL().findStudentByName(Convert.ToString(comboBox3.SelectedItem));
            dataGridView1.DataSource = ds.Tables[0];    
        }
        //调用BLL层通过班级查找学生信息
        private void button3_Click(object sender, EventArgs e)
        {
            //调用service层 返回DataSet
            string sclass;
            sclass = Convert.ToString(comboBox1.SelectedItem);
            DataSet ds = new StudentBLL().findStudentByClass(sclass);
            dataGridView1.DataSource = ds.Tables[0];
        }
        //调用BLL层通过专业查找学生信息
        private void button4_Click(object sender, EventArgs e)
        {
            string smajor = Convert.ToString(comboBox2.SelectedItem);
            DataSet ds = new StudentBLL().findStudentByMajor(smajor);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
