﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class RootWindow : Form
    {
        public RootWindow()
        {
            InitializeComponent();
        }
        //查询学生信息界面
        private void button1_Click(object sender, EventArgs e)
        {
            //创建学生信息查询页面
            StudentMsg sm = new StudentMsg();
            sm.Show();

        }
        //成绩查询界面
        private void button2_Click(object sender, EventArgs e)
        {
            //创建成绩查询界面
            GradeSelectWindow grade = new GradeSelectWindow();
            grade.Show();
        }
        //添加学生信息界面
        private void button3_Click(object sender, EventArgs e)
        {
            //创建添加学生界面
            InsertStudentWindow insert = new InsertStudentWindow();
            insert.Show();
        }
        //添加成绩界面
        private void button4_Click(object sender, EventArgs e)
        {
            //创建添加学生成绩界面
            AddGreadWindow add = new AddGreadWindow();
            add.Show();
        }
        //更改学生信息界面
        private void button5_Click(object sender, EventArgs e)
        {
            //创建更新信息界面
            UpdateWindow update = new UpdateWindow();
            //显示出来
            update.Show();
        }
        //删除界面
        private void button6_Click(object sender, EventArgs e)
        {
            //创建删除页面
            DeleteWindow delete = new DeleteWindow();
            delete.Show();

        }
        private void RootWindow_Load(object sender, EventArgs e)
        {

        }
    }
}
