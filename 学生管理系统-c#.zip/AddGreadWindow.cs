﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class AddGreadWindow : Form
    {
        public AddGreadWindow()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //封装数据
            Student s = new Student();
            s.Name = Convert.ToString(comboBox1.SelectedItem);
            s.C = Convert.ToDouble(textBox1.Text);
            s.English = Convert.ToDouble(textBox2.Text);
            s.Math = Convert.ToDouble(textBox3.Text);
            s.Chinese = Convert.ToDouble(textBox4.Text);
            s.Phy = Convert.ToDouble(textBox5.Text);
            s.Sum = s.C + s.English + s.Math + s.Chinese + s.Phy;
            //调用BLL层
            int i = new StudentBLL().addGread(s);
            if (i != 0)
            {
                success suc = new success();
                suc.Show();
                System.Threading.Thread.Sleep(2000);
                suc.Close();
                this.Close();
            }
            else
            {
                error er = new error();
                System.Threading.Thread.Sleep(2000);
                er.Close();

            }
                
        }

        private void AddGreadWindow_Load(object sender, EventArgs e)
        {
            //查询数据库的到所有的学生
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox1.Items.Add(s.Name);
            }
        }
    }
}
