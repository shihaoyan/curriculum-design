﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    
    class UserBLL
    {
        //登录用户
        public bool findUser (string name,string password)
        {
            return new UserDAL().findUser(name, password);
        }
        //通过名字查找学生信息
        public DataSet findByName(string name)
        {
            DataSet ds = new UserDAL().findByName(name);
            return ds;
        }
        //通过姓名查找成绩
        public DataSet findGreadByName(string name)
        {
            DataSet ds = new UserDAL().findGreadByName(name);
            return ds;
        }
        //注册
        public int insertUser(string name,string password)
        {
            int i = new UserDAL().insertUser(name,password);
            return i;
        }
        

        
        
    }
}
