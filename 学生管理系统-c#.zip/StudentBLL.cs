﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace 学生管理系统
{
    class StudentBLL
    {
        //调用DAL层得到所有学生信息
        //你们都会用到这个方法
        public List<Student> findAllStudent()
        {
            List<Student> list = new StudentDAL().findAllStudent();
            return list;
        }
        //查询所有学生基本信息
        public DataSet findAll()
        {
            DataSet ds = new StudentDAL().findAll();
            return ds;
        }
        //通过姓名查找所有学生信息
        public DataSet findStudentByName(string name)
        {
            DataSet ds   = new StudentDAL().findStudentByName(name);
            return ds;
        }
        //通过班级查找学生信息
        public DataSet findStudentByClass (string sclass)
        {
            DataSet ds = new StudentDAL().findStudentByClass(sclass);
            return ds;
        }
        public DataSet findStudentByMajor(string smajor)
        {
            DataSet ds = new StudentDAL().findStudentByMajor(smajor);
            return ds;
        }
        ///////////////////////////////////////
        //管理者的成绩查询
        //////////////////////////////////////

        //查询所有的成绩
        public DataSet findAllGread()
        {
            DataSet ds = new StudentDAL().findAllGread();
            return ds;
        }
        //通过名字查询成绩
        public List<Student> findGreadByName(string name)
        {
            List<Student> list = new StudentDAL().findGreadByName(name);
            return list;
        }

        ////////////////////////
        //添加学生基本信息
        //////////////////////
        public void insertStudent(Student s)
        {
            new StudentDAL().insertStudent(s);
        }

        ////////////////////////
        //添加学生成绩
        public int addGread(Student s)
        {
            int i = new StudentDAL().addGread(s);
            return i;
        }

        //////////////////////
        //更新学生信息
        public int updateMes(Student s)
        {
            int i = new StudentDAL().updateMes(s);
            return i;
        }

        ////////////////////
        //删除学生信息
        //////////////////
        public int delete(string name)
        {
            int i =  new StudentDAL().delete(name);
            return i;
        }
        

        
        
        
        
        
        
        
        
    }
}
