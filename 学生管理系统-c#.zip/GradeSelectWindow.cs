﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class GradeSelectWindow : Form
    {
        public GradeSelectWindow()
        {
            InitializeComponent();
        }
        //按照姓名查询学生成绩按钮点击执行下面代码
        private void button1_Click(object sender, EventArgs e)
        {
            //调用BLL层查询数据返回学生对象
            //
            List<Student> list = new StudentBLL().findGreadByName(Convert.ToString(comboBox1.SelectedItem));
            //list集合可以直接方法datagridview中进行显示
            dataGridView1.DataSource = list;

        }
        //显示所有成绩
        private void button2_Click(object sender, EventArgs e)
        {
            //调用service层 返回Student
            DataSet ds = new StudentBLL().findAllGread();
           
            //在窗体上显示信息
            dataGridView1.DataSource = ds.Tables[0];
        }
        //页面载入的时候执行下面代码
        private void GradeSelectWindow_Load(object sender, EventArgs e)
        {
            List<Student> list = new StudentBLL().findAllStudent();
            //遍历list集合得到每个学生并把每个学生的姓名添加到下拉列表中
            foreach (Student s in list)
            {
                comboBox1.Items.Add(s.Name); 
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
