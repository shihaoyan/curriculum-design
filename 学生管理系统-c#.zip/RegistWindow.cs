﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    public partial class RegistWindow : Form
    {
        public RegistWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox1.Text != null && textBox2.Text != "" && textBox2.Text != null && textBox2.Text == textBox3.Text)
            {
                //调用BLL层uSER
                User user = new User();
                user.Username = textBox1.Text;
                user.Password = textBox2.Text;
                int i = new UserBLL().insertUser(textBox1.Text,textBox2.Text);
                if (i != 0)
                {
                    success suc = new success();
                    suc.Show();
                    System.Threading.Thread.Sleep(2000);
                    suc.Close();
                    this.Close();
                }
                else
                {
                    error er = new error();
                    er.Show();
                    System.Threading.Thread.Sleep(2000);
                    er.Close();
                }
            }
        }

        private void RegistWindow_Load(object sender, EventArgs e)
        {

        }
    }
}
