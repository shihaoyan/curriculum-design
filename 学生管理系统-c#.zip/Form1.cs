﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 学生管理系统
{
    
    public partial class Form1 : Form
    {
        string s = UserDAL.findPath();
        public Form1()
        {
            InitializeComponent();

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                button1.Enabled = false;
            }
            radioButton1.Checked = true;
            Image img = new Bitmap(@""+s+@"\image\946d7f96fedf564077c34475a5d6b5f4.jpg");
            pictureBox1.BackgroundImage = img;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                button1.Enabled = false;
                textBox2.Enabled = true;
            }
            else if (textBox2.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                button1.Enabled = false;
                textBox1.Enabled = true;
            }
            else if (textBox1.Text == "")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Image imgs = new Bitmap(@"" + s + @"\image\946d7f96fedf564077c34475a5d6b5f4.jpg");
            pictureBox1.BackgroundImage = imgs;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                
                if (new UserBLL().findUser(textBox1.Text,textBox2.Text))
                {
                    //登陆到学生界面
                    UserWindow uw = new UserWindow();
                    uw.Show();
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                else
                {
                    error er = new error();
                    er.Show();
                    System.Threading.Thread.Sleep(1500);
                    er.Close();
                }
            }
            else
            {
                if (radioButton2.Checked && textBox1.Text == "root" && textBox2.Text == "1234")
                {
                    Image teacherimg = new Bitmap(@"" + s + @"\image\2764fd22b29c2b39a6b170bab51452c5.jpg");
                    pictureBox1.BackgroundImage = teacherimg;
                    RootWindow root = new RootWindow();
                    root.Show();
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                else
                {
                    error s = new error();
                    s.Show();
                    System.Threading.Thread.Sleep(1500);
                    s.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //创建注册界面
            RegistWindow regist = new RegistWindow();
            regist.Show();

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Image teacherimg = new Bitmap(@"" + s + @"\image\2764fd22b29c2b39a6b170bab51452c5.jpg");
            pictureBox1.BackgroundImage = teacherimg;
        }

    }
}
