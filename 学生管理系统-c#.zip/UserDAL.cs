﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace 学生管理系统
{
    class UserDAL
    {
        public static string findPath()
        {
            string path = Application.StartupPath.Substring(0, Application.StartupPath.LastIndexOf("\\"));

            return path.Substring(0, path.LastIndexOf("\\"));
        }
        string s = findPath();
        //通过用户名和密码查询用户信息
        public bool findUser(string name, string password)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+s+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select * from table1 where name ='"+name+"' and password ='"+password+"'";
                SqlCommand comm = new SqlCommand(sql, conn);
                SqlDataReader read = comm.ExecuteReader();
                while(read.Read())
                {
                    return true;
                }
                
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return false;
        }
        //通过名字查询学生信息
        public DataSet findByName(string name)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+s+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select name,sid,age,sex,school,major,sclass from  Student where name like '"+name+"'";
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds,"Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //通过名字查询学生成绩
        public DataSet findGreadByName(string name)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+s+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "select c,english,math,chinese,phy,sum from  Student where name like '"+name+"'";
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds,"Student");
                return ds;
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {

                conn.Close();

            }
            return null;
        }
        //添加用户信息
        public int insertUser(string name,string password)
        {
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename="+s+@"\User.mdf;Integrated Security=True;User Instance=True");
                conn.Open();
                string sql = "insert into table1 (name,password) values('"+name+"','"+password+"') ";
                SqlCommand com = new SqlCommand(sql,conn);
                return com.ExecuteNonQuery();
            }
            catch (Exception e2)
            {
                MessageBox.Show(e2.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
    }
}
