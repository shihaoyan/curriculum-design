﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 学生管理系统
{
    class Student
    {
        string name;

        public string Name
        {
          get { return name; }
          set { name = value; }
        }
        string sid;

        public string Sid
        {
            get { return sid; }
            set { sid = value; }
        }
        int age;

        public int Age
        {
          get { return age; }
          set { age = value; }
        }
        string sex;

        public string Sex
        {
          get { return sex; }
          set { sex = value; }
        }
        string school;

        public string School
        {
          get { return school; }
          set { school = value; }
        }
                string major;

        public string Major
        {
          get { return major; }
          set { major = value; }
        }
                string sclass;

        public string Sclass
        {
          get { return sclass; }
          set { sclass = value; }
        }
        double c;
        

        public double C
        {
          get { return c; }
          set { c = value; }
        }

        double english;

        public double English
        {
            get { return english; }
            set { english = value; }
        }
        double math;

        public double Math
        {
          get { return math; }
          set { math = value; }
        }
                double chinese;

        public double Chinese
        {
          get { return chinese; }
          set { chinese = value; }
        }
                double phy;

        public double Phy
        {
          get { return phy; }
          set { phy = value; }
        }
                double sum;

        public double Sum
        {
          get { return sum; }
          set { sum = value; }
        }
                double num;


        public double Num
        {
          get { return num; }
          set { num = value; }
        }
    }
}
